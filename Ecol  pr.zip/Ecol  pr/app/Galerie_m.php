<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Galerie_m extends Model
{
    //
}
