<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Galerie_s extends Model
{
    //
}
