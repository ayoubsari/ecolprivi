<?php

namespace App\Http\Controllers;
use Illuminate\Http\UploadedFile;
use Illuminate\Http\Request;
use App\Http\Requests\ActRequest;
use App\Actualite;
use File;
use App\Candidature;
use App\Preinscription;
class Actualite_Controler extends Controller
{
    public function __construct()
    {
       $this->middleware('auth');
    }

    public function index()
    {   
       // $act=Actualite::all();
        $act_list=Actualite::orderBy('id','desc')->paginate(2);
        $nombre=Candidature::where('vu','=', 'non')->count();
        $nombre_p=Preinscription::where('vu','=', 'non')->count();
        return view("admin.actualite.index",compact('act_list','nombre','nombre_p'));
    }

     //afficher formilaire Insertion des Actualites
    public function create(){
    	return view("admin.actualite.ajouter_actualite");
    }
    //Ajouter nouvelle actualite
    public function store(ActRequest $req){   	
        $act=new Actualite();
        $act->titre=$req->input("titre");
        $act->objet=$req->input("objet");
        if($req->hasFile('ph'))
        {
            $act->image=$req->ph->store('image');
        }
        $act->save();
       session()->flash('se',' Le Actualite bien Enregistre');
        return redirect("admin/actualite");

    }

        //permet de recuperer un Actualite

    public function edit($id){
        $act=Actualite::find($id);
       // $this->authorize('update',$act);
        return view("admin.actualite.edit_actualite",['act'=>$act]);      
    }
 //permet de modifier une Actualite
    public function update(ActRequest $req,$id){
        $act=Actualite::find($id);
        $act->titre=$req->input("titre");
        $act->objet=$req->input("objet");
        if($req->hasFile('ph'))
        {
            $act->image=$req->ph->store('image');
        }
        $act->save();
       session()->flash('se','Bien Modifier');
        return redirect("admin/actualite");

        
    }
     //permet de Supprimer un Actualite 
    public function destroy($id){
        $act=Actualite::find($id);
        $image_path = public_path("storage/image/{$act->image}");
         if (File::exists($image_path)) {
          File::delete($image_path);
          unlink($image_path);
    }
        //$this->authorize('delete',$cvs);   

    
        $act->delete();
        return redirect("admin/actualite");
        
    }
}
