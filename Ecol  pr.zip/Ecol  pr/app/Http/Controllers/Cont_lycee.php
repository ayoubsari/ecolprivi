<?php

namespace App\Http\Controllers;

use Illuminate\Http\UploadedFile;
use Illuminate\Http\Request;
use App\Lycee;
use App\Preinscription;
use App\Candidature;
class Cont_lycee extends Controller
{

     public function __construct()
    {
       $this->middleware('auth');
    }
    
        public function index()
    {
              // $gal=Galary::all();
         $gal_list=Lycee::orderBy('id','desc')->paginate(2);
         $nombre=Candidature::where('vu','=', 'non')->count();
         $nombre_p=Preinscription::where('vu','=', 'non')->count();
        return view("admin.image_lycee.index",compact('nombre','nombre_p','gal_list'));
    }

    //Ajouter nouvelle actualite
    public function store(Request $req){   	
        $gal= new Lycee();
        if($req->hasFile('ph_lycee'))
        {
            $gal->url_image=$req->ph_lycee->store('image');
        }
        $gal->save();
       session()->flash('se','Le Image lycee bien Enregistre');
        return redirect("admin/galarie_l");

    }

        //permet de recuperer un Actualite

    public function edit($id){
        $gal=Lycee::find(
            $id);
       // $this->authorize('update',$act);
        return view("admin.image_lycee.edit_lycee",['gal'=>$gal]);      
    }
 //permet de modifier une Actualite
    public function update(Request $req,$id){
        $act=Lycee::find($id);
        if($req->hasFile('ph_lycee'))
        {
            $act->url_image=$req->ph_lycee->store('image');
        }
        $act->save();
        session()->flash('se','Le Image lycee bien Modifier');
        return redirect("admin/galarie_l");

        
    }
     //permet de Supprimer un Actualite 
    public function destroy($id){

        $gallle=Lycee::find($id);
        //$this->authorize('delete',$cvs);
        $gallle->delete();

        return redirect("admin/galarie_l");
        
    }
}
