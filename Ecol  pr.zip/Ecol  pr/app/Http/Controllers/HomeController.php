<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Actualite;
use App\Lycee;
use App\Galerie_c;
use App\Galerie_p;
use App\Galerie_s;
use App\Pole_a;
use App\Pole_c;
use App\Pole_e;
use App\Pole_s;
use App\Preinscription;
use App\Candidature;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $nombre1=Galerie_s::count();
        $nombre2=Galerie_p::count();
        $nombre3= Galerie_c::count();
        $nombre4=Lycee::count();
        $nombre5=Pole_a::count();
        $nombre6=Pole_s::count();
        $nombre7=Pole_c::count();
        $nombre8=Pole_e::count();
        $nombre=Candidature::where('vu','=', 'non')->count();
        $nombre_p=Preinscription::where('vu','=', 'non')->count();
        return view('admin.index',compact('nombre1','nombre2','nombre3','nombre4','nombre5','nombre6','nombre7','nombre8','nombre','nombre_p'));
    }
    public function index1()
    {
        return view('auth.login');
    }
}
