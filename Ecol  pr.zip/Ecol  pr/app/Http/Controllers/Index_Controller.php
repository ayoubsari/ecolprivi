<?php

namespace App\Http\Controllers;
use App\Actualite;
use App\Galerie_s;
use App\Galerie_p;
use App\Galerie_c;
use App\lycee;
use App\Pole_a;
use App\Pole_e;
use App\Pole_c;
use App\Pole_s;
use App\Candidature;
use App\Preinscription;
use Illuminate\Http\Request;
use Mail;
use Auth;
use Redirect;
use Session;

class Index_Controller extends Controller
{
    //
    //function afficher page actualite

    //function de Afficher page index

    public function index1()
    {
      
      $act=Actualite::take(3)->orderBy('id','desc')->get();;
   
     return view("projet.index",["act_list"=>$act]);
    }
   public function maternelle()
   {
    $gal_m=Galerie_s::take(4)->orderBy('id','desc')->get();
    $gal_mg=Galerie_s::take(4)->orderBy('id','desc')->get();
    return view("projet.maternelle",["gal_l"=>$gal_m,"gal_m"=>$gal_mg]);
   }
    public function primaire()
   {
    $gal_m=Galerie_p::take(4)->orderBy('id','desc')->get();
    $gal_mg=Galerie_p::take(4)->orderBy('id','desc')->get();
    return view("projet.primaire",["gal_l"=>$gal_m,"gal_m"=>$gal_mg]);
   }  
    public function college()
   {
    $gal_m=Galerie_c::take(4)->orderBy('id','desc')->get();
    $gal_mg=Galerie_c::take(4)->orderBy('id','desc')->get();    
    return view("projet.college",["gal_l"=>$gal_m,"gal_m"=>$gal_mg]);
   }    
    public function lycee()
   {
    $gal_m=lycee::take(4)->orderBy('id','desc')->get();
    $gal_mg=lycee::take(4)->orderBy('id','desc')->get();
    return view("projet.lycee",["gal_l"=>$gal_m,"gal_m"=>$gal_mg]);
   }    

      public function pole_art()
   {
    $gal_m=Pole_a::take(4)->orderBy('id','desc')->get();
    $gal_mg=Pole_a::take(4)->orderBy('id','desc')->get();
    return view("projet.pole_art",["gal_l"=>$gal_m,"gal_m"=>$gal_mg]);
   }    
       public function pole_spo()
   {
    $gal_m=Pole_s::take(4)->orderBy('id','desc')->get();
    $gal_mg=Pole_s::take(4)->orderBy('id','desc')->get();
    return view("projet.pole_spo",["gal_l"=>$gal_m,"gal_m"=>$gal_mg]);
   }    
       public function pole_culture()
   {
    $gal_m=Pole_c::take(4)->orderBy('id','desc')->get();
    $gal_mg=Pole_c::take(4)->orderBy('id','desc')->get();
    return view("projet.pole_culture",["gal_l"=>$gal_m,"gal_m"=>$gal_mg]);
   }    
       public function presontation()
   {
    return view("projet.presontation");
   }   
   public function pole_ecologie()
   {
    $gal_m=Pole_e::take(4)->orderBy('id','desc')->get();
    $gal_mg=Pole_e::take(4)->orderBy('id','desc')->get();
    return view("projet.pole_ecologie",["gal_l"=>$gal_m,"gal_m"=>$gal_mg]);
   }
 public function equipe_p()
   {
    return view("projet.equipe_p");
   }  
          public function fond()
   {
    return view("projet.fond");
   }  

   public function candidature()
   {
    return view("projet.candidature");
   }
   public function preinscription()
   {
    return view ("projet.preinscription");
   }
    

    //function de detail 

    public function detail($id){
        $act=Actualite::find($id);
       // $this->authorize('update',$act);
        return view("projet.detail",['act'=>$act]);      
    }
    public function getContact()
    {
         return view('projet.contact');
    }
   public function postContact(Request $req)
    {
        $this->validate($req,[ 
            'email'=>'required | email',
            'subject'=>'min:3',
            'message'=>'min:10'
            ]);
          $data=array(
            'email'=>$req->email,
            'subject'=>$req->subject,
            'content'=>$req->message
            );
          Mail::send('projet.email',$data,function($message)use ($data)
          { 
            $message->from($data['email']);//email configuration 
            $message->to('ayoubsari8@gmail.com');//change to email destination 
            $message->subject($data['subject']);
          });
          // check for failures
     //         if (Mail::failures()) {
     //             dd(var_dump(Mail::failures));
    //          }
          session()->flash('se','Message Bien Envoyér');
          return redirect('/contact');
    }
    //  function de Galary
        public function afficher_galery()
    {
      // $act=Actualite::take(5)->orderBy('created_at','desc')->get();
         $gal=Galary::take(600)->orderBy('id','desc')->get();
         return view("projet.galarie",["gal_list"=>$gal]);
    }

        //Ajouter nouvelle actualite
    public function Ajouter_Cv(Request $req){     
        $cond=new Candidature();
        $cond->nom=$req->input("nom");
        $cond->numero_tel=$req->input("tel");
        $cond->email=$req->input("email");
        $cond->destination=$req->input("dest");
        if($req->hasFile('cv'))
        {
            $cond->url=$req->cv->store('image');
        }
        $cond->message=$req->input("message");
        $cond->vu="non";
        $cond->save();
        session()->flash('se',' Bien Envoyer');
        return redirect("candidature");

    }
    public function Ajouter_per(Request $req){     
        $prsinsc=new Preinscription();
        $prsinsc->nom=$req->input("nom");
        $prsinsc->numero_tel=$req->input("tel");
        $prsinsc->email=$req->input("email");
        $prsinsc->nom_enfant=$req->input("nom_enfant");
        $prsinsc->message=$req->input("message");
        $prsinsc->vu="non";
        $prsinsc->save();
        session()->flash('se',' Bien Envoyer');
        return redirect("preinscription");

    }




}
