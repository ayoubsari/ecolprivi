<?php

namespace App\Http\Controllers;
use Illuminate\Http\UploadedFile;
use Illuminate\Http\Request;
use App\Pole_e;
use App\Preinscription;
use App\Candidature;
use Storage;
class Pole_e_Controle extends Controller
{
    public function __construct()
    {
       $this->middleware('auth');
    }
    
        public function index()
    {
         $nombre=Candidature::where('vu','=', 'non')->count();
         $nombre_p=Preinscription::where('vu','=', 'non')->count();
         $gal_list=Pole_e::orderBy('id','desc')->paginate(2);
        return view("admin.pole_e.index",compact('nombre','nombre_p','gal_list'));
    }

    //Ajouter nouvelle actualite
    public function store(Request $req){    
        $gal= new Pole_e();
        if($req->hasFile('phs'))
        {
            $gal->url_image=$req->phs->store('image');
        }
        $gal->save();
       session()->flash('se','Le Image Pôle Ecologie bien Enregistre');
        return redirect("admin/pole_e");

    }

        //permet de recuperer un Actualite

    public function edit($id){
        $gal=Pole_e::find(
            $id);
       // $this->authorize('update',$act);
        return view("admin.pole_e.edit_pole_s",['gal'=>$gal]);      
    }
 //permet de modifier une Actualite
    public function update(Request $req,$id){
        $act=Pole_e::find($id);
        if($req->hasFile('phs'))
        {
            $act->url_image=$req->phs->store('image');
        }
        $act->save();
        session()->flash('se','Le Image Pôle Ecologie bien Modifier');
        return redirect("admin/pole_e");

        
    }
     //permet de Supprimer un Actualite 
    public function destroy($id){

        $gal=Pole_e::find($id);
        //$this->authorize('delete',$cvs);
        Storage::delete($gal->url_image);
        $gal->delete();

        return redirect("admin/pole_e");
        
    }
}
