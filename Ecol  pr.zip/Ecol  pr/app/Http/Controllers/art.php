<?php

namespace App\Http\Controllers;

use Illuminate\Http\UploadedFile;
use Illuminate\Http\Request;
use App\Galerie_p;
use App\Preinscription;
use App\Candidature;
use Storage;
class art extends Controller
{
    

     public function __construct()
    {
       $this->middleware('auth');
    }
    
        public function index()
    {
              // $gal=Galary::all();
                 $nombre=Candidature::where('vu','=', 'non')->count();
         $nombre_p=Preinscription::where('vu','=', 'non')->count();
         $gal_list=Galerie_p::orderBy('id','desc')->paginate(2);
        return view("admin.image_primary.index",compact('gal_list','nombre','nombre_p'));
    }

    //Ajouter nouvelle actualite
    public function store(Request $req){   	
        $gal= new Galerie_p();
        if($req->hasFile('ph_primary'))
        {
            $gal->url_image=$req->ph_primary->store('image');
        }
        $gal->save();
       session()->flash('se','Le Image primary bien Enregistre');
        return redirect("admin/galarie_p");

    }

        //permet de recuperer un Actualite

    public function edit($id){
        $gal=Galerie_p::find(
            $id);
       // $this->authorize('update',$act);
        return view("admin.image_primary.edit_primary",['gal'=>$gal]);      
    }
 //permet de modifier une Actualite
    public function update(Request $req,$id){
        $act=Galerie_p::find($id);
        if($req->hasFile('ph_primary'))
        {
            $act->url_image=$req->ph_primary->store('image');
        }
        $act->save();
        session()->flash('se','Le Image primary bien Modifier');
        return redirect("admin/galarie_p");

        
    }
     //permet de Supprimer un Actualite 
    public function destroy($id){

        $gale=Galerie_p::find($id);
        //$this->authorize('delete',$cvs);
        Storage::delete($gal->url_image);
        $gale->delete();

        return redirect("admin/galarie_p");
        
    }
}
