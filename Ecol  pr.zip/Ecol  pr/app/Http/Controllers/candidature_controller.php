<?php

namespace App\Http\Controllers;

use Illuminate\Http\UploadedFile;
use Illuminate\Http\Request;
use App\Candidature;
use App\Preinscription;
use Storage;
class candidature_controller extends Controller
{
    

     public function __construct()
    {
       $this->middleware('auth');
    }
    
        public function index()
    {
              // $gal=Galary::all();
         $gal_list=Candidature::orderBy('id','desc')->paginate(5);
         $nombre=Candidature::count();
         $nombre_p=Preinscription::count();
        return view("admin.afficher_cv",compact('gal_list','nombre','nombre_p'));
    }
    public function destroy($id){

        $gale=Candidature::find($id);
        //$this->authorize('delete',$cvs);
        Storage::delete($gal->url);
        $gale->delete();

        return redirect("admin/galarie_p");       
    }

    public function update()
    {
              Candidature::where('vu', '=', 'non')->update(['vu' => 'oui']);
        return redirect("admin/candidature");
    }
}
