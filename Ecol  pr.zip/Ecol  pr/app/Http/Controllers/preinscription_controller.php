<?php

namespace App\Http\Controllers;

use Illuminate\Http\UploadedFile;
use Illuminate\Http\Request;
use App\Preinscription;
use App\Candidature;
class preinscription_controller extends Controller
{
    

     public function __construct()
    {
       $this->middleware('auth');
    }
    
        public function index()
    {
         $nombre=Candidature::where('vu','=', 'non')->count();
         $nombre_p=Preinscription::where('vu','=', 'non')->count();
         $gal_list=Preinscription::orderBy('id','desc')->paginate(5);
        return view("admin.afficher_per",compact('nombre','nombre_p','gal_list'));
    }
    public function destroy($id){

        $gale=Preinscription::find($id);
        //$this->authorize('delete',$cvs);
        Storage::delete($gal->url_image);
        $gale->delete();

        return redirect("admin/preinscription");
        
    }

    public function update()
    {
        Preinscription::where('vu', '=', 'non')->update(['vu' => 'oui']);
        return redirect("admin/preinscription");
    }
}
