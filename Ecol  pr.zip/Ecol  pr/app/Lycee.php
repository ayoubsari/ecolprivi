<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lycee extends Model
{
    //
}
