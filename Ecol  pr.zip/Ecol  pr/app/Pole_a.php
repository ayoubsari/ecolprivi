<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pole_a extends Model
{
    //
}
