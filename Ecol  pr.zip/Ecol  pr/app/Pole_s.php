<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pole_s extends Model
{
    //
}
