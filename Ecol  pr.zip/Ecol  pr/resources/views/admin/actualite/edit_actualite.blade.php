@extends('layouts.navbar_adminn')

@section('content_adminn')
            <div class="content well">
              <h2>Modifier  des Actualites</h2>
            </div>


<form style="margin:0px 5px;" action="{{ url('admin/actualite/'.$act->id)}} " method="post" enctype="multipart/form-data">
<input type="hidden" name="_method" value="PUT">
			 {{csrf_field()}}
     <!--Start titre -->
	<div class="form-group @if($errors->get('titre'))  has-error  @endif">
	<input type="text" name="titre" placeholder="Titre" class="form-control" value="{{$act->titre}}">
				@if($errors->get('titre'))                   
                    @foreach($errors->get('titre') as $message)                    
                     <li>{{$message}}</li>
                    @endforeach
				@endif
	</div>
     <!--End titre -->
     <!--Start Objet -->
	<div class="form-group @if($errors->get('objet'))  has-error  @endif">
	<textarea name="objet" placeholder="Objet" class="form-control" style="height: 100px;">{{$act->objet}}</textarea>
				@if($errors->get('objet'))                   
                    @foreach($errors->get('objet') as $message)                    
                     <li>{{$message}}</li>
                    @endforeach
				@endif	
    </div>
     <!--End  Objet -->
    <div class="form-group">
				<label for="">Image</label>
				<input type="file" class="form-control" name="ph">
				</div>
    <button type="submit" class="btn btn-primary">
        <i class="fa fa-refresh"></i> Modifier
    </button>
	
</form>
@endsection