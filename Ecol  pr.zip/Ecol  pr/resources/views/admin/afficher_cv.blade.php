@extends('layouts.navbar_adminn')


@section('content_adminn')
<!-- Start Page index Actualite -->
            <div class="content well">
              <h2>Afficher des Candidatures </h2>
            </div>
            <div class="clear"></div>
  <table class="table table-bordered table-responsive  table-striped">
  <caption><i class="fa fa-list" aria-hidden="true"></i></caption>
    <tr>
    <th>Nom</th>
    <th>Tel</th> 
    <th>Email</th>
    <th>Cv</th>
    <th>Message</th>
    <th>date reception</th>
    </tr>
    @foreach($gal_list as $value)
    <tr style="text-align: center;">
      <td>{{$value->nom}}</td>
      <td>{{$value->numero_tel	}}</td>
      <td>{{$value->Email}}</td>
      <td><a href="{{asset('storage/'.$value->url)}}"><img src="{{asset('assets\img\telecharger.png')}}" width="40"  height="40" /></a></td>
      <td>{{$value->message}}</td>
      <td>{{ str_limit($value->created_at,10) }}</td>     
    </tr>
    @endforeach
  </table>
  <center>{{$gal_list->links()}}</center>
  

<!-- End Page Index Admin -->


@endsection