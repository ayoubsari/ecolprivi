@extends('layouts.navbar_adminn')

@section('content_adminn')
            <div class="content well">
              <h2>Modifier  des maternelle</h2>
            </div>


<form style="margin:0px 5px;" action="{{ url('admin/galarie_m/'.$gal->id)}} " method="post" enctype="multipart/form-data">
<input type="hidden" name="_method" value="PUT">
			 {{csrf_field()}}

    <div class="form-group">
				<label for="">Image</label>
				<input type="file" class="form-control" name="phs">
				</div>
    <button type="submit" class="btn btn-primary">
        <i class="fa fa-refresh"></i> Modifier
    </button>
	
</form>
@endsection