@extends('layouts.navbar_adminn')


@section('content_adminn')
<!-- Start Page index Actualite -->
            <div class="content well">
              <h2>Gestion des Galeries Pôle Artistique</h2>
            </div>
            <div class="clear"></div>
            @include('part.flash')
       <button type="button" class="btn btn-primary bs" data-toggle="modal" data-target="#myModal"  style="font-weight: bold;margin-bottom: 5px"><i class="fa fa-plus" aria-hidden="true"></i> Ajouter Pôle Artistique </button>
  <table class="table table-bordered table-responsive  table-striped">
  <caption><i class="fa fa-list" aria-hidden="true"></i></caption>
    <tr>
    <th>Images</th>
    <th>Date</th> 
    <th>Operation</th>
    </tr>
    @foreach($gal_list as $value)
    <tr>
      <td><img src="{{asset('storage/'.$value->url_image)}}" alt="..." height="100" width="200"></td>
      <td>{{ str_limit($value->created_at,10) }}</td>
      <td>
      <!-- Start Supprimer -->
  {{-- Confirm Delete --}}
  <div class="modal fade" id="modal-delete" tabIndex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">
            ×
          </button>
          <h4 class="modal-title">Confirmer Supprimer</h4>
        </div>
        <div class="modal-body">
          <p class="lead">
            <i class="fa fa-question-circle fa-lg"></i>  
            Voulez vous Supprimer?
          </p>
        </div>
        <div class="modal-footer">
          <form   action="{{ url('admin/pole_a/'.$value->id)}}"  method="post">
          {{ csrf_field() }}
          {{ method_field('DELETE') }}
          <button type="submit" class="btn btn-primary">
          <i class="fa fa-trash-o"></i> Oui
          </button>
          <button type="button" class="btn btn-danger"
          data-dismiss="modal"><i class="fa fa-times-circle"></i> Annuler</button>

          </form>
        </div>
      </div>
    </div>
    </div>
<!-- End Supprimer-->
      <a href="{{url('admin/pole_a/'.$value->id.'/edit') }}" class="btn btn-small btn btn-primary"><i class="fa fa-refresh"></i> Modifier</a>

      <button type="button" class="btn btn-small btn-danger" data-toggle="modal" data-target="#modal-delete" ><i class="fa fa-trash-o"></i> Supprimer</button>
      </td>
      
    </tr>
    @endforeach
  </table>
  <center>{{$gal_list->links()}}</center>
  

    <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Ajouter nouvelle Galery</h4>
        </div>
        <div class="modal-body">
          <form style="margin:0px 5px;" action="{{ url('admin/pole_a/store')}} " method="post" enctype="multipart/form-data">

       {{csrf_field()}}
    <div class="form-group">
        <label for="">Image</label>
        <input type="file" class="form-control" name="phs">
        </div>
  <button type="submit" class="btn btn-primary">
    <i class="fa fa-floppy-o" aria-hidden="true"></i> Enregistrer
  </button>
  <button type="button" class="btn btn-danger pull-right" data-dismiss="modal">
  <i class="fa fa-times-circle" aria-hidden="true"></i> Anuller</button>
</form>
        </div>
      </div>
      
    </div>
  </div>
  <!-- End Model -->
<!-- End Page Index Admin -->


@endsection