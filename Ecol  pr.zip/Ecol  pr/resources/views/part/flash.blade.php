@if(session()->has('se'))
 			<div class="alert alert-info" role="alert">
 			{{session()->get('se')}}	
 			</div>
 		
@endif