@extends('layouts.navbar')
@section('titre')
Actualite
@endsection
@section('content')
<!-- Start Des Formations-->
<div class="formation">
  <div class="container">

            @foreach($act_list as $value)
            <div class="box_formation">
              <h3>{{$value->titre}}</h3>

              <div class="date_p">
                Posté par: {{str_limit($value->created_at,10)}}
              </div>
              <div class="row">

                <div class="col-md-3 col-sm-3 col-xs-12">
                  <img src="{{asset('storage/'.$value->image)}}" style="width: 100%;
            height: 128px;" >
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <p>{{ str_limit($value->objet,310)}}(...) </p>
                  <a href="{{url('detail/'.$value->id) }}" class="btn btn-primary" >Voir plus...<i class="fa fa-chevron-circle-right"></i></a>
                </div>
              </div>
            </div>
            
            @endforeach
  </div>

 <center> {{$act_list->links()}}  </center>
</div>
<!-- End Des Formations-->
@endsection