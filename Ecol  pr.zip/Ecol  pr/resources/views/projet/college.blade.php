@extends('layouts.navbar')
@section('titre')
Collège
@endsection
@section('content')
<!--Start cover -->
<div class="cover maternelle">
      <div class="container">
     <h2>Collège</h2>
      </div>
</div>
<!--End cover -->
<!--Start page maternelle -->
<div class="cycle">
  <div class="container">
    <div class="row">
          <div class="col-md-3">
            <ul class="menu_verticale">
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="{{ url('/maternelle') }}" >Maternelle</a></li>
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="{{ url('/primaire') }}">Primaire</a></li>
              <li><i class="fa fa-arrow-right act_m" aria-hidden="true"></i><a href="{{ url('/college') }}" class="act_m">Collège</a></li>
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="{{ url('/lycee') }}">Lycée</a></li>
            </ul>
           <div class="carre cover">
             <h1 class="text-center">Collège</h1>
            <center> <img src="{{ asset('assets\img\sec4.jpg') }}" width="150" height="250"   /></center>
            <h3 class="text-center">Exposé Alimentation</h3>
             
           </div>
        </div>
      <div class="col-md-9">
                <div class="menu_top">

                      <ul>
                        <li><a href="">Accueil</a>></li>
                        <li><a href="">Cycles</a>></li>
                        <li>Collège</li>
                      </ul>

                  
                </div>
        <div class="clear"></div>
        <h2 class="pre">Présentation</h2>
        <p class="para_m">Le cycle du collège est celui de la consolidation des apprentissages. Les connaissances étudiées au cours du cycle primaire sont approfondies et les élèves s’initient à d’autres sciences telles, la physique, la chimie et les sciences de la vie et de la terre. La maîtrise des langues doit leur permettre l’accès à des œuvres littéraires. Les productions écrites des élèves doivent s’enrichir, au cours des années, d’une réflexion personnelle s’appuyant sur une culture générale de plus en plus performante.
</p>

              <div class="inscri_m cover">
              <div class="row">
                <div class="col-md-6">
                   <h2>Collège</h2>
                   <p>Consolider ses connaissances, approfondir ses savoirs</p>
                </div>
               <div class="col-md-6">
                  <a href="{{ url('/preinscription') }}" class="pull-right"><i class="fa fa-file-text-o"></i>S'inscrire</a>
                </div>
              </div>
               
              </div>
             <!--Start Slider-->
<div id="carousel" class="carousel slide sliderr" data-ride="carousel">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    @foreach($gal_l as $key=>$value)
    <div class="item {{ $key == 0 ? ' active' : '' }}">
      <img src="{{ asset('storage/'.$value->url_image) }}" class="img-responsive">
     
    </div>
    @endforeach
  </div>

  <!-- Controls -->
  <a class="left carousel-control hiden-xs" href="#carousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control hiden-xs" href="#carousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<div id="carousel-thumbs" class="carousel slide slidee">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      @foreach($gal_m as $key=>$value)
      <div class="col-xs-3 {{ $key == 0 ? ' active' : '' }}"onclick="$('#carousel').carousel({{ $key }});">
        <img src="{{ asset('storage/'.$value->url_image) }}" class="img-responsive">
      </div>
      @endforeach
    </div>
    
<!-- Controls -->
  </div>
</div>
<!-- End Slider -->
              <!-- Start Menu page -->
              <br><br><br>
         <div class="menu_pédagie">
                <ul class="list-unstyled list-menu">
                  <li class="act_color" data-class="one">Objectif</li>
                  <li data-class="two">pédagogie</li>
                  <li data-class="three">Activités</li>
                  <li data-class="for">Equipements</li>
                </ul>
                <div  class="clear"> </div>
                        <div class="tabs_content">
                        <div class="one">
                        <p>L’accès au collège s’opère à la fin de la sixième année, après un test interne de passage.</p>
                        <p>Il s’agit de renforcer :</p>
                        <ul class="list-contenu">
                          <li>L’apprentissage des langues  ( maîtrise orale et écrite du Français, de l’Arabe et de l’Anglais )</li>
                          <li>Les notions mathématiques en Français et en Arabe</li>
                          <li>La pratique expérimentale en sciences ( Science de la Vie et de la Terre, Physique et Chimie )</li>
                          <li>La spécialisation dans une discipline artistique.</li>
                          <li>L’élaboration de projets personnels.</li>
                        </ul>
                        </div>
                        <div class="two">
                         <p> Le Collège du groupe scolaire Benabdallah à Marrakech, propose une pédagogie alternative basée sur le programme suivant :</p>
                         <ul class="list-contenu">
                           <li>Culture scientifique renforcée par une pratique expérimentale bilingue</li>
                           <li>Coaching (accompagnement dans le projet personnel des élèves)</li>
                           <li>Interventions de professionnels</li>
                           <li>Ouverture sur le monde de l’entreprise</li>
                           <li>Bilan d’acquisitions régulier</li>
                           <li>24 élèves / classe</li>
                         </ul>
                        </div>
                        <div class="three">
                          <p>Le Collège du groupe scolaire Benabdallah à Marrakech, propose des activités basées sur le programme suivant </p>
                          <ul class="list-contenu">
                            <li>Spécialisation dans la pratique des arts selon le choix de l’élève</li>
                            <li>Education à la citoyenneté</li>
                            <li>Sport et compétitions : natation, sport d’équipe, gymnastique,  athlétisme</li>
                            <li>Découverte de l’entreprise (stages et visites)</li>
                            <li>Ateliers de technologie et robotique</li>
                            <li>Psalmodie du Saint Coran</li>
                            <li>Initiation à la vie associative</li>
                          </ul>
                        </div>
                        <div class="for">
                          <p>Le Collège du groupe scolaire Benabdallah à Marrakech, propose les équipements suivant à ses élèves :</p>
                          <ul class="list-contenu">
                            <li>Piscine couverte chauffée</li>
                            <li>Terrain omnisports</li>
                            <li>Gymnase couvert</li>
                            <li>Laboratoire de sciences et technologie</li>
                            <li>Salle d’informatique</li>
                            <li>Salle de conférences</li>
                            <li>Salles d’arts</li>
                            <li>Bibliothèque</li>
                            <li>Amphithéâtre plein air</li>
                            <li>Tableaux interactifs</li>
                            <li>Réfectoires équipés</li>
                            <li>Aire de détente</li>
                            <li>Vidéo surveillance</li>
                          </ul>
                        </div>
                        </div>
          </div>

    
    </div>
    </div>
    </div>
    </div>
<!-- end page maternelle -->

@endsection