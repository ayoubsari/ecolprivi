@extends('layouts.navbar')
<!-- Start title -->
@section('titre')
Details
@endsection
<!-- End Title  -->
@section('content')
<div class="cover maternelle">
      <div class="container">
     <h2>Actualites</h2>
      </div>
</div>
<div class="detail">
	<div class="container">
		<div class="row">
					<div class="col-md-8">
					<h3>{{$act->titre}}</h3>
					<div class="date_p">
					Posté par: {{str_limit($act->created_at,10)}}
					</div>
					<a  href="">
					<img src="{{asset('storage/'.$act->image)}}">
					</a>
					<p>
					{{$act->objet}}
					</p>
					<a href="{{ url('/') }}" class="btn btn-primary" style="margin-bottom: 20px;">Retour</a>
					</div>
		</div>
    </div>
</div>
@endsection
<!-- Start Details -->


<!-- End Detials -->