<html>
<head>
<style type="text/css">
div{
	color:black;padding:6px;
}
.pr{
padding:6px;border-left: 2px solid black;float: left;width: 40%;
}
.pr b,.pr_right b{
	color:gray;
}
.pr_right{
	float: left;border-left: 2px solid black;padding: 6px;width: 50%;
}
</style>
</head>
<body>

<p>content</p>
<div >

<p  class="pr">
<b>Description ecole:</b><br>
Ecol informatique, Réseaux et Télécommunication<br>
<b>Adresse</b><br>
École Privi des  de Safi
Route Sidi Bouzid, BP 63, 46000-Safi, Maroc <br>
</p>
<p class="pr_right">
<b>Equipe:</b> Mathématiques et Traitement de l'Information<br>
<b>Web:</b> www.ecol_privi.com<br>
<b>GSM:</b> 0649.26.46.42<br>
</p>
<p style="font-style: italic;clear: both;">Copyright © Ecole Nationale</p>
</div>
</body>
</html>

