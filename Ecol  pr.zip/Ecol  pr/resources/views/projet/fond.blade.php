@extends('layouts.navbar')
@section('titre')
Mot du fondateur
@endsection
@section('content')
<!--Start cover -->
<div class="cover maternelle">
      <div class="container">
     <h2>Mot du fondateure</h2>
      </div>
</div>
<!--End cover -->
<!--Start page maternelle -->
<div class="cycle">
  <div class="container">
    <div class="row">
          <div class="col-md-3">
            <ul class="menu_verticale">
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a  href="presontation.html" >Présentation</a></li>
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="equipe_p.html">Equipe pédagogique</a></li>
               <li><i class="fa fa-arrow-right act_m" aria-hidden="true"></i><a class="act_m"  href="fond.html">Mot du fondateur</a></li>
            </ul>
           <div class="carre cover">
             <h1 class="text-center">Présentation</h1>
            <center> <img src="{{ asset('assets\img\logo.png') }}" width="150" height="250"   /></center>
            <h3 class="text-center">Exposé Alimentation</h3>
             
           </div>
        </div>
      <div class="col-md-9">
                <div class="menu_top">

                      <ul>
                        <li><a href="">Accueil</a>></li>
                        <li>Mot du fondateur</li>
 
                      </ul>

                  
                </div>
        <div class="clear"></div>
        <h2 class="pre text-center">Mot du fondateure</h2>
        <p class="para_m">Mon rêve a toujours été de contribuer à la formation des futurs actrices et acteurs de notre société. La réalisation de ce rêve vient aujourd’hui se concrétiser par la construction du groupe scolaire privé Benabdallah.
</p>
<p class="para_m">Nous avons veillé à ce que notre établissement puisse allier des espaces d’éducation, de sport, de culture sans oublier la nature.  Nous avons voulu concevoir un espace de vie exceptionnel. Chaque composante de notre école vient répondre à notre volonté d’ouvrir à votre enfant les portes du savoir et de la culture.</p>


<p class="para_m">Notre souci est d’offrir à nos élèves toutes les possibilités de découvrir le potentiel qui existe en eux, de le développer afin de l’investir en « confiance en soi ». Et c’est parce que la société d’aujourd’hui évolue rapidement et connaît des changements auxquels nos enfants sont confrontés chaque jour, nous voulons dans notre enceinte leur donner tous les atouts afin qu’ils puissent à chance égale s’ouvrir sur le monde de demain, un monde qui devient de plus en plus élitiste.</p>
<p class="para_m">Nous les accompagnerons si vous voulez bien nous faire confiance, pour faire d’eux des actrices et acteurs qui compteront pour construire notre Maroc de demain.</p>




<div class="fts" style="padding: 20px;">
</div>

              <!-- Start Images page -->
              <center><img src="{{ asset('assets\img\fond.jpg') }}" style="width: 65%"> </center>
              <!-- End Images pages -->

<div class="fts" style="padding: 70px;">
</div>
    
    </div>
    </div>
    </div>
    </div>
<!-- end page maternelle -->
@endsection