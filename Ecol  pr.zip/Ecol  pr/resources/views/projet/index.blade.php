<!DOCTYPE html>
<html>
<head>
  <title>Ecol  Privie</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="{{ asset('assets\img\logoe.ico') }}"/>
<link href="https://fonts.googleapis.com/css?family=Dosis|Leckerli+One" rel="stylesheet">
<link rel="stylesheet"  href="{{ asset('assets\style\bootstrap.min.css') }}">
<link rel="stylesheet"  href="{{ asset('assets\style\font-awesome.css') }}">
<link rel="stylesheet"  href="{{ asset('assets\style\normalize.css') }}">
<link rel="stylesheet"  href="{{ asset('assets\style\style.css') }}">
<link rel="stylesheet"  href="{{ asset('assets\style\animate.css') }}">
<link href="https://fonts.googleapis.com/css?family=Dosis|Leckerli+One" rel="stylesheet">
</head>

<body>
<!-- Start navbar -->
<nav class="navbar navbar-default">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
            <span class="navbar-brand" >
    
</span>
      <img  src="{{ asset('assets\img\logo.png') }}" 
      style="width: 100px;height: 65px;    padding-top: 1px;">

    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav navbar-right">
        <li><a href="{{url('/')}}">ACCUEIL</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">CYCLES <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="{{ url('/maternelle') }}">Maternelle</a></li>
            <li><a href="{{ url('/primaire') }}">Primaire</a></li>
            <li><a href="{{ url('/college') }}">Collége</a></li>
            <li><a href="{{ url('/lycee') }}">Lycée</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">PÔLES D’ ACTIVITES <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="{{ url('/pole_art') }}">Pôle Artistique</a></li>
            <li><a href="{{ url('/pole_spo') }}">Pôle Sportif</a></li>
            <li><a href="{{ url('/pole_culture') }}">Pôle Culturel</a></li>
            <li><a href="{{ url('/pole_ecologie') }}">Pôle Ecologie</a></li>          
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">A PROPROS DE NOUS <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="{{ url('/presontation') }}">Présentation</a></li>
            <li><a href="{{ url('/equipe_p') }}">Equipe pédagogique</a></li>
            <li><a href="{{ url('/fond') }}">Mot du fondateur</a></li>
          </ul>
        </li>
        <li><a href="{{ url('/contact') }}">CONTACT</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<!-- End navbar -->

<!--Start Slider  bar-->
<!--Start Slider 1 -->
<div class="section">
  
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
       <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
        <li data-target="#carousel-example-generic" data-slide-to="1" ></li>
        <li data-target="#carousel-example-generic" data-slide-to="2" ></li>

      </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
        <div class="item  active">
      <img  src="{{ asset('assets\img\sec4.jpg') }}" alt="...">
      <div class="carousel-caption hidden-xs hidden-sm">
     <h1 class="animated fadeInRight">"Comprendre le monde , constrouire l'avenire ." 
     </h1>
     <h1 class="animated fadeInLeft">Materelle-Primaire-Collége-Lycée</h1>
            <a  href="{{ url('/preinscription') }}" class="btn btn-primary btn_inscri animated fadeInLeft">
              S'inscrire
            </a>&nbsp&nbsp&nbsp
            <a href="{{ url('/maternelle') }}" class="btn btn-primary btn_inscri animated fadeInRight">
              Accedé aux cercle
            </a>
            <div class="iconn">
             <a href="#" data-value="port"> <i class="fa fa-chevron-down" aria-hidden="true"></i> </a>
            </div>
      </div>
    </div>

 
          <div class="item ">
      <img src="{{ asset('assets\img\sec1.jpg') }}" alt="...">
      <div class="carousel-caption hidden-xs hidden-sm">
     <h1 class="animated fadeInRight">Des activités pour s’épanouir et s’ouvrir au monde. 
    </h1>
            <a href="{{ url('/maternelle') }}"  class="btn btn-success btn-college animated fadeInLeft">
              <i class="fa fa-book" aria-hidden="true"></i> Maternelle
            </a>&nbsp&nbsp&nbsp
            <a href="{{ url('/primaire') }}" class="btn btn-info btn-college animated fadeInRight">
             <i class="fa fa-university" aria-hidden="true"></i>  Primaire
            </a>&nbsp&nbsp&nbsp
            <a href="{{ url('/college') }}" class="btn btn-primary btn-college animated fadeInRight">
             <i class="fa fa-graduation-cap" aria-hidden="true"></i>  Collége
            </a>&nbsp&nbsp&nbsp
            <a href="{{ url('/lycee') }}" class="btn btn-primary btn-college animated fadeInRight" style="background-color: #76b9f5;border: 1px solid #76b9f5;">
             <i class="fa fa-graduation-cap" aria-hidden="true"></i>  Lycée
            </a>
             <div class="iconn">
            <a href="#" data-value="port" >  <i class="fa fa-chevron-down" aria-hidden="true"></i></a>
            </div>
      </div>
    </div>
          <div class="item ">
      <img  src="{{ asset('assets\img\sec6.jpg') }}" alt="...">
      <div class="carousel-caption hidden-xs hidden-sm">
     <h1 class="animated fadeInRight">"Comprendre le monde , constrouire l'avenire ." 
     </h1>
     <h1 class="animated fadeInLeft">Materelle-Primaire-Collége-Lycée</h1>
          <a  href="{{ url('/preinscription') }}" class="btn btn-primary btn_inscri animated fadeInLeft">
              S'inscrire
            </a>&nbsp&nbsp&nbsp
            <a href="{{ url('/maternelle') }}" class="btn btn-primary btn_inscri animated fadeInRight">
              Accedé aux cercle
            </a>
            <div class="iconn">
             <a href="#" data-value="port"> <i class="fa fa-chevron-down" aria-hidden="true"></i> </a>
            </div>
      </div>
    </div>
        </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


</div>
<!-- End slider 1 -->

<!--End   Slidar bar-->
<!--Start cover -->
<div class="cover" id="port">
      <div class="container">
          <div class="row text-center">
            <div class="col-md-6">
            <h1 class="wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">Vous êtes parent ou élève ?</h1>
             <a href="#" class="btn btn-primary wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">
                      <i class="fa fa-envelope" aria-hidden="true"></i> ACCEDER
             </a>
            </div>
            <div class="col-md-6">
            <h1 class="wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">Vous êtes enseignant ?</h1>
                 <a href=" {{ url('/candidature') }}" class="btn btn-primary wow zoomIn"  data-wow-offset="10"  data-wow-iteration="1">
                      <i class="fa fa-envelope-o" aria-hidden="true"></i> POSTULER
             </a>
            </div>
          </div>
      </div>
</div>
<!--End cover -->
<!--Start section1 -->
<div class="section1">
    <div class="container">
      <div class="row text-center"> 
            <div class="col-md-6 wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">
            <h2>LE GROUPE SCOLAIRE PRIVÉ </h2>
            <p>Le Groupe scolaire Benabdallah privé enseigne le programme du Ministère de l’éducation nationale Marocain. Notre école, située à Marrakech, accueille vos enfants en maternelle, au primaire, au collège et au lycée dans un espace de vie de 7400 m2 qui a été conçu avec un souci d’équilibre entre l’éducation, l’art, le sport, la culture et le respect de l’environnement.<br>

Située dans un quartier résidentiel calme (lotissement Yasmine), d’une accessibilité fluide (accès par la route de Casablanca à 3 voies), notre structure offre un cadre agréable et ludique à vos enfants. Notre établissement accueille les enfants à partir de la maternelle ( 2 ans ) et assure leur évolution jusqu’à l’obtention de leur baccalauréat au sein du même groupe scolaire. Attentive au rythme d’apprentissage des enfants, notre équipe pédagogique, en collaboration avec des professeurs finlandais, suivra ses élèves tout au long de leur scolarité afin de faire de leur parcours une réussite. L’épanouissement de votre enfant est au cœur du projet de notre groupe, et c’est dans cette optique que notre école a été fondée, avec des espaces de développement et de vie uniques à Marrakech.</p>
            </div>
            <div class="col-md-6 wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">
            <img src="{{ asset('assets\img\sec7.jpg') }}"/>
            </div>
      </div>
    </div>
</div>
<!--End   section1 -->

<!--Start Section 2 -->
<div class="section2">
  <div class="opacity">
       <div class="container"> 
        <div class="row text-center" >
          <div class="col-md-3">
            <a href="{{ url('/pole_art') }}" class="wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">
              <h4>Pôle Artistique</h4>
              <p>salle de teatre<br>barre plastique<br>de musique<br>et de danse</p>
            </a>
        
          </div>
          <div class="col-md-3">
            <a href="{{ url('/pole_spo') }}" class="wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">
              <h4>Pôle Sportif</h4>
              <p>Salle de <br>psychomotricité<br>piscine couverte<br>terrain omnisports<br>et gymnase</p>
            </a>     
             
          </div>
          <div class="col-md-3">
            <a href="{{ url('/pole_culture') }}" class="wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">
              <h4>Pôle Culturel</h4>
              <p>Salle de conférence <br>bibliothéque<br>de médiathéque.</p>
            </a>      
          </div>
          <div class="col-md-3">
            <a href="{{ url('/pole_ecologie') }}" class="wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">
              <h4>Pôle Ecologie<</h4>
              <p>Ferme ,jardin<br>pédagogique,<br>ateliers<br>découvertes</p>
            </a> 
          </div>
        </div>
       </div>
   </div>
</div>
<!--End   Section 2 -->
<!-- Start Actualitée -->
<!--start Actialite  -->
<div class="acti wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">
  <div class="container">

      <h2 class="text-center">NOS ACTUALITÉS</h2>
    <div class="row">
    @foreach($act_list as $value)
            <div class="col-md-4 col-sm-4">

              <div class="box">
                <img src="{{asset('storage/'.$value->image)}}">
                <p class="date">Posté par: {{str_limit($value->created_at,10)}}</p>
                <p class="detail">{{ str_limit($value->objet,200)}}... </p>
                <a href="{{url('detail/'.$value->id) }}" class="btn btn-primary s">Voir plus...<i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
</a>
              </div>
             
            </div>

    @endforeach

  </div>

</div>
</div>
<!-- End  Actialite  -->
<!--Start derigant -->
<div class="derig" >
  <div class="container">
  <h2 class="text-center wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">les Derigants</h2>
    <div class="row text-center wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">
      <div class="col-md-3">
        <img  src="{{ asset('assets\img\fond1.jpg') }}" class="img-circle" />
        <p>MR BENABDALLAH<br>
Fondateur</p>
      </div>
      <div class="col-md-3">
        <img  src="{{ asset('assets\img\Pauline.jpg') }}" class="img-circle"/>
       <p>MME PAULINE<br>
Co-fondatrice</p>
      </div>
      <div class="col-md-3">
        <img  src="{{ asset('assets\img\3.jpg') }}" class="img-circle"/>
       <p>MR LUC MORISOT<br>
Directeur Collège & Lycée</p>
      </div>
      <div class="col-md-3">

        <img  src="{{ asset('assets\img\4.jpg') }}"  class="img-circle"/>
      <p>MME PAULINE<br>
Co-fondatrice</p>
      </div>

    </div>
  </div>
</div>
<!--End derigant -->
<!--Start Contact Nous -->
<div class="contact_nous wow zoomIn" data-wow-offset="10"  data-wow-iteration="1">
  <div class="container">
  <h2>Contact nous</h2>
  <p>A votre disposition pour tout complément d’informations</p>

<p>Téléphone : +212 5 24 26 46 42 Mobile : +212 6 49 19 02 78 Fax : +212 5 24 40 35 40</p>

<p>mail : ayoubsabri56@gmail.com</p>
<form action="{{ url('contact')}}" method="post">
{{csrf_field()}}
    <div class="row">
    
          <div class="col-md-6">  
          <input type="text" name="nom" placeholder="Nom" class="form-control" data-toggle="p" data-content="Enter le Nom s'il vous plais"  id="user_name" data-placement="bottom" required>
          <input type="text" name="email" placeholder="Email" class="form-control" data-toggle="em" data-content="Enter le email est bien valider exmepl: ayoub56@gmail.com" id="user_email" data-placement="bottom" required>
      <input type="text" name="subject" placeholder="Sujet" class="form-control"     data-toggle="pr" data-content="Enter le Sujet s'il vous plais" data-placement="bottom"   id="user_prenom" required>
          </div>
          <div class="col-md-6">  
          <textarea placeholder="Message" name="message" class="form-control" id="user_message"
     data-toggle="prm" data-content="Enter le Message s'il vous plais"  data-placement="bottom" required></textarea>
          </div>
          
      
    </div>
    <center><button type="submit" class="btn btn-primary">Envoyer</button> </center>
    <br><center>@include('part.flash'); </center>
    </form>
  </div>

</div>
<!--End   Contact Nous -->

<!-- Start  Footer -->
<div class="footer">
<div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12">
          <h3>Contact</h3>
          <p>Adresse : Angle Boulevard Tantan et rue Bengeurir G.H.N° 4 Almanar Anfa Casablanca 20160 Maroc</p>
        </div>
        <div class="col-md-4 col-sm-6 col-xs-12">
          <h3>Réseaux sociaux</h3>
                <div class="icon">
                  <a  href="" target="_blank"><i class="fa fa-facebook"></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-twitter "></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-google-plus"></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-linkedin"></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-youtube"></i></a>
                 </div>
        </div>
        <div class="col-md-4 col-sm-6 col-xs col-xs-12">
          <h3>Mots clés</h3>
          <p>Ecole, Architecture d'intérieur, Casablanca, Maroc, Design, Design d'objets, Design Graphique, Digital, Formation accréditée, Enseignement supérieur,</p>
        </div>
      </div>
</div>
</div>
<div class="pied">
  <p class="text-center">Copyrights © Développer By<a style="text-decoration: none;color:black;font-weight: bold;" href="http://www.devosystem.com" target="_blank"> Ayoub Sabri </a><span id="date_m"></span></p></div>
<!-- End  Fotter -->
<!--Start Flesh-->
<span class="flech">
  <i class="fa fa-angle-up" aria-hidden="true"></i>
</span>
<!-- End Flesh -->
<script src="{{ asset('assets\js\jquery-3.1.1.min.js') }}"></script>
<script src="{{ asset('assets\js\bootstrap.min.js') }}"></script>
<script src="{{ asset('assets\js\validate_contact.js') }}"></script>
              <script src="{{ asset('assets\js\wow.min.js') }}"></script>
              <script>
              new WOW().init();
              </script>
</body>
</html>
