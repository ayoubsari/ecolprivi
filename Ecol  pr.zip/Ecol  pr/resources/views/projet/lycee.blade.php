@extends('layouts.navbar')
@section('titre')
Lycée
@endsection
@section('content')
<!--Start cover -->
<div class="cover maternelle">
      <div class="container">
     <h2>Lycée</h2>
      </div>
</div>
<!--End cover -->
<!--Start page maternelle -->
<div class="cycle">
  <div class="container">
    <div class="row">
          <div class="col-md-3">
            <ul class="menu_verticale">
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="{{ url('/maternelle') }}" >Maternelle</a></li>
              <li><i class="fa fa-arrow-right " aria-hidden="true"></i><a href="{{ url('/primaire') }}" >Primaire</a></li>
              <li><i class="fa fa-arrow-right " aria-hidden="true"></i><a href="{{ url('/college') }}" >Collège</a></li>
              <li><i class="fa fa-arrow-right act_m" aria-hidden="true"></i><a href="{{ url('/lycee') }}" class="act_m">Lycée</a></li>
            </ul>
           <div class="carre cover">
             <h1 class="text-center">Lycée</h1>
            <center> <img src="{{ asset('assets\img\sec4.jpg') }}" width="150" height="250"   /></center>
            <h3 class="text-center">Exposé Alimentation</h3>
             
           </div>
        </div>
      <div class="col-md-9">
                <div class="menu_top">

                      <ul>
                        <li><a href="">Accueil</a>></li>
                        <li><a href="">Cycles</a>></li>
                        <li>Lycée</li>
                      </ul>

                  
                </div>
        <div class="clear"></div>
        <h2 class="pre">Présentation</h2>
        <p class="para_m">Le lycée correspond aux trois dernières années de l’enseignement secondaire. La classe de seconde est une classe de détermination, ensuite l’élève choisit sa section en classe de première, puis le cycle se termine par l’examen du Baccalauréat, le diplôme qui permettra la poursuite d’études supérieures. Les lycéens vont perfectionner leur apprentissage des langues étrangères, enrichir leur culture générale grâce à des activités artistiques et à des voyages organisés, décider de leur future orientation professionnelle, et ouvrir leur esprit aux valeurs d’humanisme et de tradition, essentielles pour réussir sa scolarité et sa vie.
</p>

              <div class="inscri_m cover">
              <div class="row">
                <div class="col-md-6">
                   <h2>Lycée</h2>
                   <p>Dernière étape avant l’enseignement supérieur</p>
                </div>
               <div class="col-md-6">
                  <a href="{{ url('/preinscription') }}" class="pull-right"><i class="fa fa-file-text-o"></i>S'inscrire</a>
                </div>
              </div>
               
              </div>
<!--Start Slider-->
<div id="carousel" class="carousel slide sliderr" data-ride="carousel">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    @foreach($gal_l as $key=>$value)
    <div class="item {{ $key == 0 ? ' active' : '' }}">
      <img src="{{ asset('storage/'.$value->url_image) }}" class="img-responsive">
     
    </div>
    @endforeach
  </div>

  <!-- Controls -->
  <a class="left carousel-control hiden-xs" href="#carousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control hiden-xs" href="#carousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<div id="carousel-thumbs" class="carousel slide slidee">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      @foreach($gal_m as $key=>$value)
      <div class="col-xs-3 {{ $key == 0 ? ' active' : '' }}"onclick="$('#carousel').carousel({{ $key }});">
        <img src="{{ asset('storage/'.$value->url_image) }}" class="img-responsive">
      </div>
      @endforeach
    </div>
    
<!-- Controls -->
  </div>
</div>
<!-- End Slider -->
<br><br><br>
              <!-- Start Menu page -->
         <div class="menu_pédagie">
                <ul class="list-unstyled list-menu">
                  <li class="act_color" data-class="one">Objectif</li>
                  <li data-class="two">pédagogie</li>
                  <li data-class="three">Activités</li>
                  <li data-class="for">Equipements</li>
                </ul>
                <div  class="clear"> </div>
                        <div class="tabs_content">
                        <div class="one">
                         <ul class="list-contenu">
                      <li>Perfectionnement linguistique</li>
                      <li>Initiation à l ‘économie dès la seconde</li>
                      <li>Devoirs réguliers en conditions d’examen</li>
                      <li>Cours de communication</li>
                      <li>Coaching (accompagnement dans le projet personnel des élèves)</li>
                      <li>Approche pédagogique en effectif limité</li>
                      <li>Spécialisation dans la pratiques des arts</li>
                      <li>Compétition sportives : natation, sport d’équipe, gymnastique…</li>
                      <li>Interventions de professionnels</li>
                      <li>Ouverture sur le monde de l’entreprise</li>
                      <li>Méthodes et stratégies d’apprentissage</li>
                      <li>Préparation aux concours d’entrée aux écoles supérieures</li>
                         </ul>
                        </div>
                        <div class="two">
                         <ul class="list-contenu">
                  <li>Encourager la réflexion et la production intellectuelle</li>
                  <li>Parfaire l’excellence linguistique et perfectionner la maitrise des langues étrangères</li>
                  <li>Enrichir la culture générale nécessaire à la poursuites d’études supérieures</li>
                  <li>Se spécialiser dans une discipline artistique</li>
                  <li>Optimiser l’exploitation de l’outil numérique</li>
                  <li>Préparer un cursus de formation et d’orientation professionnelle</li>
                         </ul>
                        </div>
                        <div class="three">
                          <ul class="list-contenu">
              <li>Spécialisation dans la pratique des arts selon le choix de l’élève</li>
              <li>Sorties culturelles et voyages à l’étranger</li>
              <li>Sport et compétitions : natation, sport d’équipe, gymnastique, athlétisme</li>
              <li>Atelier de technologie et robotique</li>
              <li>Psalmodie du Saint Coran</li>
              <li>Initiation à la vie associative</li>
                          </ul>
                        </div>
                        <div class="for">
                          <ul class="list-contenu">
            <li>Gymnase couvert</li>
            <li>Laboratoires de sciences et technologie</li>
            <li>Salle d’informatique</li>
            <li>Salle de conférence</li>
            <li>Salles d’arts</li>
            <li>BCD (bibliothèque et centre de documentation)</li>
            <li>Amphithéâtre plein air</li>
            <li>Piscine couverte chauffée</li>
            <li>Terrain omnisports</li>
            <li>Tableaux interactifs</li>
            <li>Vidéo-surveillance</li>
            <li>Aire de détente</li>
            <li>Réfectoire équipé</li>
                          </ul>
                        </div>
                        </div>
          </div>

    
    </div>
    </div>
    </div>
    </div>
<!-- end page maternelle -->
@endsection