@extends('layouts.navbar')
@section('titre')
Pôle Artistique
@endsection
@section('content')


<!--Start cover -->
<div class="cover maternelle">
      <div class="container">
     <h2>Pôle Artistique</h2>
      </div>
</div>
<!--End cover -->
<!--Start page maternelle -->
<div class="cycle">
  <div class="container">
    <div class="row">
          <div class="col-md-3">
            <ul class="menu_verticale">
              <li><i class="fa fa-arrow-right act_m" aria-hidden="true"></i><a href="{{ url('/pole_art') }}" class="act_m">Pôle Artistique</a></li>
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="{{ url('/pole_spo') }}">Pôle Sportif</a></li>
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="{{ url('/pole_culture') }}">Pôle Culturel</a></li>
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="{{ url('/pole_ecologie') }}" >Pôle Ecologie</a></li>
            </ul>
           <div class="carre cover">
             <h1 class="text-center">Pôle Artistique</h1>
            <center> <img src="{{ asset('assets\img\sec4.jpg') }}" width="150" height="250"   /></center>
            <h3 class="text-center">Exposé Alimentation</h3>
             
           </div>
        </div>
      <div class="col-md-9">
                <div class="menu_top">

                      <ul>
                        <li><a href="">Accueil</a>></li>
                        <li><a href="">pôles d’ activites</a>></li>
                        <li>Pôle Artistique</li>
                      </ul>

                  
                </div>
        <div class="clear"></div>
        <h2 class="pre">Développer sa créativité</h2>
        <p class="para_m">La pratique des arts occupe une place importante au groupe scolaire Benabdallah. Nous sommes convaincus que ces enseignements développent, chez nos élèves, des compétences transversales et contribuent à leur épanouissement en sollicitant leur créativité, essentielle dans la construction de la personnalité. 
</p>


<!-- Start Accordion -->



            <div class="set">
        <a ><i class="fa fa-plus"></i>Théâtre</a>


<div class="content">
<p>
Le théâtre est un art pluridisciplinaire : il fait appel à des pratiques esthétiques, rythmiques, corporelles, langagières. Il favorise la connaissance et la maîtrise de soi, de son corps et de sa voix, la pratique de la communication et de l’empathie, l’expression des émotions et des sentiments, la découverte d’œuvres littéraires. Faire du théâtre, c’est aller à la rencontre de soi et des autres.
</p>
</div>


            </div>


            <div class="set">
        <a ><i class="fa fa-plus"></i>Arts Plastique</a>


<div class="content">
<p>
 Pour les élèves du GSB, les cours d’arts plastiques sont le début d’une nouvelle aventure où ils découvrent le pouvoir de la création : exploration de techniques et de matériaux variés et dès la maternelle, contact avec les œuvres d’artistes. Sensibilisation, initiation, découverte et expression artistique dessinent la trame de ces cours. Des cours de peinture sont également enseignés et viennent ainsi compléter la gamme des arts plastiques. Pour cela, ces ateliers permettent aux enfants les plus timides de s’exprimer et de s’affirmer. Créativité, confiance, estime de soi, chaque élève tire bénéfice de ce moment de création.
</p>
</div>


            </div>

            <div class="set">
        <a ><i class="fa fa-plus"></i>Musique</a>


<div class="content">
<p>
ave gone down in the West behind the hills into shadow. Who shall gather the smoke of the deadwood burning, Or behold the flowing years from the Sea returning? The days have gone down in the West behind the hills into shadow. Who shall gather the smoke of the deadwood burning, Or behold the flowing years from the Sea returning? The days have gone down in the West behind the hills into shadow. Who shall gather the smoke of the deadwood burning, Or behold the flowing years from the Sea returning? The days have gone down in the West behind the hills into shadow. Who shall gather the smoke of the deadwood burning, Or behold the flowing years from the Sea returning?
</p>
</div>


            </div>
    
            <div class="set">
        <a ><i class="fa fa-plus"></i>Danse</a>


<div class="content">
<p>
Activité ludique avant tout, la danse permet à l’élève de développer sa sensibilité et de se construire à travers le plaisir que procure le mouvement. La danse est une voie qui favorise l’imaginaire et la créativité. Elle est le moment d’éclosion du potentiel expressif de chacun. Nos élèves acquièrent les principes fondamentaux de cette discipline, dans la joie d’une expérience de partage.
</p>
</div>


            </div>


<!-- End Accordion -->
<!--Start Slider-->
<div id="carousel" class="carousel slide sliderr" data-ride="carousel">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    @foreach($gal_l as $key=>$value)
    <div class="item {{ $key == 0 ? ' active' : '' }}">
      <img src="{{ asset('storage/'.$value->url_image) }}" class="img-responsive">
     
    </div>
    @endforeach
  </div>

  <!-- Controls -->
  <a class="left carousel-control hiden-xs" href="#carousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control hiden-xs" href="#carousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<div id="carousel-thumbs" class="carousel slide slidee">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      @foreach($gal_m as $key=>$value)
      <div class="col-xs-3 {{ $key == 0 ? ' active' : '' }}"onclick="$('#carousel').carousel({{ $key }});">
        <img src="{{ asset('storage/'.$value->url_image) }}" class="img-responsive">
      </div>
      @endforeach
    </div>
    
<!-- Controls -->
  </div>
</div>
<!-- End Slider -->


              <!-- Start Menu page -->
<div class="fts" style="padding: 50px;">
</div>
    
    </div>
    </div>
    </div>
    </div>
<!-- end page maternelle -->

@endsection