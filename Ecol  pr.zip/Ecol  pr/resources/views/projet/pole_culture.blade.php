@extends('layouts.navbar')
@section('titre')
Pôle Culturel
@endsection
@section('content')


<!--Start cover -->
<div class="cover maternelle">
      <div class="container">
     <h2>Pôle Sportif</h2>
      </div>
</div>
<!--End cover -->
<!--Start page maternelle -->
<div class="cycle">
  <div class="container">
    <div class="row">
          <div class="col-md-3">
            <ul class="menu_verticale">
              <li><i class="fa fa-arrow-right " aria-hidden="true"></i><a href="{{ url('/pole_art') }}" >Pôle Artistique</a></li>
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="{{ url('/pole_spo') }}">Pôle Sportif</a></li>
              <li><i class="fa fa-arrow-right act_m" aria-hidden="true"></i><a href="{{ url('/pole_culture') }}" class="act_m">Pôle Culturel</a></li>
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="{{ url('/pole_ecologie') }}" >Pôle Ecologie</a></li>
            </ul>
           <div class="carre cover">
             <h1 class="text-center">Pôle Culturel</h1>
            <center> <img src="{{ asset('assets\img\logo.png') }}"  width="150" height="250"   /></center>
            <h3 class="text-center">Exposé Alimentation</h3>
             
           </div>
        </div>
      <div class="col-md-9">
                <div class="menu_top">

                      <ul>
                        <li><a href="">Accueil</a>></li>
                        <li><a href="">pôles d’ activites</a>></li>
                        <li>Pôle Culturel</li>
                      </ul>

                  
                </div>
        <div class="clear"></div>
        <h2 class="pre">Éveiller sa curiosité</h2>
        <p class="para_m">Ce pôle a pour vocation d’être au service de tous les enseignements.
</p>
<p class="para_m">L’utilisation du numérique renforce les apprentissages fondamentaux : jeux concernant les langues, les mathématiques, les arts graphiques</p>
<p class="para_m">Il est un outil essentiel dans les travaux personnels de recherche : production d’écrits, recherches d’informations, utilisation de banques de données. L’élève est amené à maîtriser cet outil pour concevoir des présentations (type power point) et à produire des documents argumentés et synthétiques.</p>

<p class="para_m">Les bibliothèques sont dotées d’ouvrages en langues française, arabe et anglaise : romans, contes, encyclopédies et dictionnaires. Dès la maternelle, la manipulation du livre permet au jeune enfant de se familiariser avec le code écrit, de développer son imaginaire, d’apprécier la lecture ;  puis au cycle primaire, de  la pratiquer lui-même. C’est aussi  en lisant que  l’élève acquiert sa culture générale à travers les œuvres littéraires de référence, en pratiquant l’analyse de texte dans ses dimensions littéraires mais aussi historiques, sociologiques, géographiques… et d’être ainsi confrontés à tous les courants de pensée philosophiques, artistiques et religieux de l’humanité.</p>

<ul style="margin-left:20px;font-weight: bold;font-size: 17px;padding: 10px;">
<li>Médiathèque des petits</li>
<li>BCD  (bibliothèque centre de documentation) ,</li>
<li>Salle d’informatique et équipement TBI (tableaux interactifs)</li>
<li>Salle de conférence</li>
</ul>



<!--Start Slider-->
<div id="carousel" class="carousel slide sliderr" data-ride="carousel">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    @foreach($gal_l as $key=>$value)
    <div class="item {{ $key == 0 ? ' active' : '' }}">
      <img src="{{ asset('storage/'.$value->url_image) }}" class="img-responsive">
     
    </div>
    @endforeach
  </div>

  <!-- Controls -->
  <a class="left carousel-control hiden-xs" href="#carousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control hiden-xs" href="#carousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<div id="carousel-thumbs" class="carousel slide slidee">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      @foreach($gal_m as $key=>$value)
      <div class="col-xs-3 {{ $key == 0 ? ' active' : '' }}"onclick="$('#carousel').carousel({{ $key }});">
        <img src="{{ asset('storage/'.$value->url_image) }}" class="img-responsive">
      </div>
      @endforeach
    </div>
    
<!-- Controls -->
  </div>
</div>
<!-- End Slider -->
              <!-- Start Menu page -->
<div class="fts" style="padding: 70px;">
</div>
    
    </div>
    </div>
    </div>
    </div>
<!-- end page maternelle -->
@endsection