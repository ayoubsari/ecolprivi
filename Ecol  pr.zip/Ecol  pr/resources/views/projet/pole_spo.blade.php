@extends('layouts.navbar')
@section('titre')
Pôle Artistique
@endsection
@section('content')
<!DOCTYPE html>

<!--Start cover -->
<div class="cover maternelle">
      <div class="container">
     <h2>Pôle Sportif</h2>
      </div>
</div>
<!--End cover -->
<!--Start page maternelle -->
<div class="cycle">
  <div class="container">
    <div class="row">
          <div class="col-md-3">
            <ul class="menu_verticale">
              <li><i class="fa fa-arrow-right " aria-hidden="true"></i><a href="{{ url('/pole_art') }}" >Pôle Artistique</a></li>
              <li><i class="fa fa-arrow-right act_m" aria-hidden="true"></i><a href="{{ url('/pole_spo') }}" class="act_m">Pôle Sportif</a></li>
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="{{ url('/pole_culture') }}" >Pôle Culturel</a></li>
              <li><i class="fa fa-arrow-right " aria-hidden="true"></i><a href="{{ url('/pole_ecologie') }}"  >Pôle Ecologie</a></li>
            </ul>
           <div class="carre cover">
             <h1 class="text-center">Pôle Sportif</h1>
            <center> <img src="{{ asset('assets\img\logo.png') }}"  width="150" height="250"   /></center>
            <h3 class="text-center">Exposé Alimentation</h3>
             
           </div>
        </div>
      <div class="col-md-9">
                <div class="menu_top">

                      <ul>
                        <li><a href="">Accueil</a>></li>
                        <li><a href="">pôles d’ activites</a>></li>
                        <li>Pôle Sportif</li>
                      </ul>

                  
                </div>
        <div class="clear"></div>
        <h2 class="pre">Un esprit sain dans un corps sain</h2>
        <p class="para_m">L’activité physique et sportive fait partie intégrante de l’apprentissage psychomoteur d’un enfant. Elle favorise le développement musculaire et l’acquisition de l’équilibre, de la coordination des gestes et de la précision. Elle aide l’enfant à prendre conscience de son corps et de la perception de celui-ci dans l’espace.
</p>
<p class="para_m">Le sport permet d’acquérir confiance, autonomie, esprit de décision, entraide, et fair play.</p>
<ul style="margin-left:20px;font-weight: bold;font-size: 17px;padding: 10px;">
<li>Salle de psychomotricité (cycle maternelle)</li>
<li>Terrain omnisports ( football, basketball, handball)</li>
<li>Piste d’athlétisme</li>
<li>Gymnase couvert</li>
<li>Piscine semi-olympique couverte chauffée</li>
</ul>

<!-- Start Accordion -->


          <div class="set">
        <a><i class="fa fa-plus"></i>Psychomotricité (cycle maternelle)</a>


<div class="content">
<p>
La psychomotricité représente la première étape dans la vie de tout être humain, moment utilitaire où le vécu affectif et relationnel donne vie au corps et libère l’action motrice, source du développement cognitif. De cette manière, elle permet à chaque être de vivre la globalité de sa personne tant motrice qu’affective et cognitive. « L’éducation psychomotrice, c’est donner à l’enfant le droit et le temps de construire lui-même sa corporalité, de se structurer dans le temps et dans l’espace, en relation avec un environnement humain et matériel riche et varié. »
</p>
</div>


            </div>

          <div class="set">
        <a><i class="fa fa-plus"></i>Sports Collectifs</a>


<div class="content">
<p>
Au-delà des bienfaits physiques, les sports collectifs sont une excellente école de la vie. Ils favorisent le développement de l’estime de soi, la confiance en soi et permettent aux enfants d’être acceptés par leurs pairs, en trouvant leur place au sein d’un groupe.Le sport est important aux yeux des enfants, notamment chez les jeunes garçons qui l’utilisent pour se mesurer les uns aux autres. De manière générale, les enfants qui pratiquent des activités sportives sont plus sociables et s’intègrent et s’adaptent plus facilement à leur environnement.
</p>
</div>


            </div>

          <div class="set">
        <a ><i class="fa fa-plus"></i>Natation</a>


<div class="content">
<p>La natation est sans aucun doute l’un des sports le plus complet tant physiquement que mentalement.</p>

<p>C’est une activité saine qui favorise le bon développement de l’enfant. En effet, la natation est une discipline sportive extrêmement importante dans le développement psychomoteur de l’enfant. Elle implique tous les muscles du corps, stimule l’appareil respiratoire et limite les risques de scoliose.</p>

<p>Dispensés par nos maîtres-nageurs qualifiés, les cours de natation sont basés sur un apprentissage ludique et en fonction de l’évolution des enfants.</p>
</div>


            </div>

          <div class="set">
        <a ><i class="fa fa-plus"></i>Athlétisme</a>


<div class="content">
<p>
L’athlétisme est un sport très complet, composé de nombreuses spécialités (course de haies, course de fond, saut, sprint, lancé…) qui permettent aux enfants de ne jamais se lasser.Ce sport développe la vitesse, la détente, l’endurance cardio-vasculaire et la coordination.C’est un complément à tous les autres sports.
</p>
</div>


            </div>



<!-- Start Accordion -->
<!--Start Slider-->
<div id="carousel" class="carousel slide sliderr" data-ride="carousel">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    @foreach($gal_l as $key=>$value)
    <div class="item {{ $key == 0 ? ' active' : '' }}">
      <img src="{{ asset('storage/'.$value->url_image) }}" class="img-responsive">
     
    </div>
    @endforeach
  </div>

  <!-- Controls -->
  <a class="left carousel-control hiden-xs" href="#carousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control hiden-xs" href="#carousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<div id="carousel-thumbs" class="carousel slide slidee">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      @foreach($gal_m as $key=>$value)
      <div class="col-xs-3 {{ $key == 0 ? ' active' : '' }}"onclick="$('#carousel').carousel({{ $key }});">
        <img src="{{ asset('storage/'.$value->url_image) }}" class="img-responsive">
      </div>
      @endforeach
    </div>
    
<!-- Controls -->
  </div>
</div>
<!-- End Slider -->
              <!-- Start Menu page -->
<div class="fts" style="padding: 70px;">
</div>
    
    </div>
    </div>
    </div>
    </div>
<!-- end page maternelle -->

@endsection