@extends('layouts.navbar')
@section('titre')
Présentation
@endsection
@section('content')

<!--Start cover -->
<div class="cover maternelle">
      <div class="container">
     <h2>Présentation</h2>
      </div>
</div>
<!--End cover -->
<!--Start page maternelle -->
<div class="cycle">
  <div class="container">
    <div class="row">
          <div class="col-md-3">
            <ul class="menu_verticale">
              <li><i class="fa fa-arrow-right act_m" aria-hidden="true"></i><a class="act_m" href="presontation.html" >Présentation</a></li>
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="equipe_p.html">Equipe pédagogique</a></li>
               <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="fond.html">Mot du fondateur</a></li>
            </ul>
           <div class="carre cover">
             <h1 class="text-center">Présentation</h1>
            <center> <img src="{{ asset('assets\img\logo.png') }}"  width="150" height="250"   /></center>
            <h3 class="text-center">Exposé Alimentation</h3>
             
           </div>
        </div>
      <div class="col-md-9">
                <div class="menu_top">

                      <ul>
                        <li><a href="">Accueil</a>></li>
                        <li>Présentation</li>
 
                      </ul>

                  
                </div>
        <div class="clear"></div>
        <h2 class="pre text-center">Présentation</h2>
        <p class="para_m">Le Groupe Scolaire Privé Benabdallah est un espace de vie de 7400 m2 qui a été conçu avec un souci d’équilibre entre l’éducation, le sport,la culture et le respect de l’environnement Située dans un quartier résidentiel calme (lotissementYasmine), d’une accessibilité fluide (accès par la route de Casablanca à 3 voies), notre école offre un cadre agréable et ludique à vos enfants.
</p>
<p class="para_m">Avec une équipe pédagogique professionnelle et expérimentée, nos élèves seront suivis tout au long de leur scolarité afin de faire de leur parcours une réussite. L’épanouissement de votre enfant est au cœur du projet de notre groupe, et c’est dans cette optique que notre école a été fondée, avec des espaces de développement et de vie uniques à Marrakech.</p>


<p class="para_m">Nous l’aiderons ainsi à découvrir chacun de ses atouts créatifs en participant à nos nombreuses activités parascolaires. Des encadrants responsables, la surveillance, des équipements homologués aux normes en vigueur assurent la sécurité de vos enfants.</p>




<div class="fts" style="padding: 20px;">
</div>

              <!-- Start Images page -->
              <img src="{{ asset('assets\img\sec7.jpg') }}" style="width: 100%">
              <!-- End Images pages -->

<div class="fts" style="padding: 70px;">
</div>
    
    </div>
    </div>
    </div>
    </div>
<!-- end page maternelle -->

@endsection