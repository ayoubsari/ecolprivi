@extends('layouts.navbar')
@section('titre')
Primaire
@endsection
@section('content')

<!--Start cover -->
<div class="cover maternelle">
      <div class="container">
     <h2>Primaire</h2>
      </div>
</div>
<!--End cover -->
<!--Start page maternelle -->
<div class="cycle">
  <div class="container">
    <div class="row">
          <div class="col-md-3">
            <ul class="menu_verticale">
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="{{ url('/maternelle') }}" >Maternelle</a></li>
              <li><i class="fa fa-arrow-right act_m" aria-hidden="true"></i><a href="{{ url('/primaire') }}" class="act_m" >Primaire</a></li>
              <li><i class="fa fa-arrow-right " aria-hidden="true"></i><a href="{{ url('/college') }}" >Collège</a></li>
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="{{ url('/lycee') }}">Lycée</a></li>
            </ul>
           <div class="carre cover">
             <h1 class="text-center">Primaire</h1>
            <center> <img src="{{ asset('assets\img\sec4.jpg') }}"  width="150" height="250"   /></center>
            <h3 class="text-center">Exposé Alimentation</h3>
             
           </div>
        </div>
      <div class="col-md-9">
                <div class="menu_top">

                      <ul>
                        <li><a href="">Accueil</a>></li>
                        <li><a href="">Cycles</a>></li>
                        <li>Primaire</li>
                      </ul>

                  
                </div>
        <div class="clear"></div>
        <h2 class="pre">Présentation</h2>
        <p class="para_m">Les six années d’enseignement primaire constituent le  cycle des enseignements fondamentaux. Ce cycle va permettre aux élèves d’acquérir des savoir et des compétences de base : maîtriser la communication orale, lire, écrire (grammaire, orthographe, syntaxe, vocabulaire), les techniques opératoires, les systèmes numériques de base, les premiers concepts de géométrie, la capacité de réflexion dans la résolution de problèmes, de développer leur autonomie et leur curiosité intellectuelle et culturelle, d’apprendre à organiser avec méthode leur travail, de développer leurs compétences physiques et artistiques.</p>

              <div class="inscri_m cover">
              <div class="row">
                <div class="col-md-6">
                   <h2>Primaire</h2>
                   <p>Le parcours de découvertes et d'apprentissages fondamentaux</p>
                </div>
               <div class="col-md-6">
                  <a href="{{ url('/preinscription') }}" class="pull-right"><i class="fa fa-file-text-o"></i>S'inscrire</a>
                </div>
              </div>
               
              </div>
<!--Start Slider-->
<div id="carousel" class="carousel slide sliderr" data-ride="carousel">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    @foreach($gal_l as $key=>$value)
    <div class="item {{ $key == 0 ? ' active' : '' }}">
      <img src="{{ asset('storage/'.$value->url_image) }}" class="img-responsive">
     
    </div>
    @endforeach
  </div>

  <!-- Controls -->
  <a class="left carousel-control hiden-xs" href="#carousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control hiden-xs" href="#carousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<div id="carousel-thumbs" class="carousel slide slidee">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      @foreach($gal_m as $key=>$value)
      <div class="col-xs-3 {{ $key == 0 ? ' active' : '' }}"onclick="$('#carousel').carousel({{ $key }});">
        <img src="{{ asset('storage/'.$value->url_image) }}" class="img-responsive">
      </div>
      @endforeach
    </div>
    
<!-- Controls -->
  </div>
</div>
<!-- End Slider -->
              <br><br><br>

              <!-- Start Menu page -->
         <div class="menu_pédagie">
                <ul class="list-unstyled list-menu">
                  <li class="act_color" data-class="one">Objectif</li>
                  <li data-class="two">pédagogie</li>
                  <li data-class="three">Activités</li>
                  <li data-class="for">Equipements</li>
                </ul>
                <div  class="clear"> </div>
                        <div class="tabs_content">
                        <div class="one">
                        <p>En fonction de son âge et de son développement personnel, l’élève acquiert :</p>
                        <ul class="list-contenu">
                          <li>Des compétences de communication ( savoir s’exprimer )</li>
                          <li>Des compétences stratégiques ( analyser, raisonner et agir )</li>
                          <li>Des compétences méthodologiques ( savoir s’organiser, utiliser des outils )</li>
                          <li>Des compétences culturelles ( s’initier à des pratiques artistiques, à découvrir son environnement )</li>
                          <li>Des compétences technologiques ( savoir utiliser les techniques modernes comme l’informatique )</li>
                          <li>Des compétences physiques ( pratique de sports ).</li>
                        </ul>
                        </div>
                        <div class="two">
                         <p> Le cycle Primaire du groupe scolaire Benabdallah à Marrakech, propose une pédagogie alternative :</p>
                         <ul class="list-contenu">
                           <li>Formation continue des enseignants</li>
                           <li>Enseignement des Mathématiques et Sciences en français, renforcé par une pratique expérimentale</li>
                           <li>Cours d’Anglais et ateliers d’expression orale dès le CP</li>
                           <li>Cours de communication pour les élèves non-arabophones</li>
                           <li>Coaching collectif</li>
                           <li>Interventions de professionnels</li>
                           <li>Bilan d’acquisitions régulier</li>
                           <li>Sensibilisation au respect de l’environnement</li>
                         </ul>
                        </div>
                        <div class="three">
                          <p>Le cycle Primaire du groupe scolaire Benabdallah à Marrakech, propose un cycle d’initiation aux activités sur le programme suivant :</p>
                          <ul class="list-contenu">
                            <li>Théâtre : perfectionnement en technique théâtrale</li>
                            <li>Musique : écoute et création musicale</li>
                            <li>Sport : natation,sport d’équipe, gymnastique, athlétisme</li>
                            <li> Arts plastiques : histoire de l’art et développement de la créativité</li>
                            <li>Danse</li>
                            <li>Ateliers de menuiserie</li>
                            <li>Ateliers découverte : arts culinaires, robotique, écologie …</li>
                            <li>Psalmodie du Saint Coran</li>
                          </ul>
                        </div>
                        <div class="for">
                          <p>Le cycle Primaire du groupe scolaire Benabdallah à Marrakech, propose les équipements suivant à ses élèves :</p>
                          <ul class="list-contenu">
                            <li>Piscine couverte chauffée</li>
                            <li>Terrain omnisports</li>
                            <li>Gymnase couvert</li>
                            <li>Salle d’informatique</li>
                            <li>Salle de conférences</li>
                            <li>Bibliothèque</li>
                            <li>Atelier de menuiserie</li>
                            <li>Tableaux interactifs</li>
                            <li>Réfectoires équipés</li>
                            <li>Aire de récréation</li>
                            <li>Vidéo surveillance</li>
                          </ul>
                        </div>
                        </div>
          </div>

    
    </div>
    </div>
    </div>
    </div>
<!-- end page maternelle -->

@endsection