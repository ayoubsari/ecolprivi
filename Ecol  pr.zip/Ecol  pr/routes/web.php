<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*Start Des  Routes de Navigation*/
//Route::get('/ecol', 'Index_Controller@index1');
Route::get('/','Index_Controller@index1');
Route::get('/ayoub',function()
	{
            return view("auth.register");
	});
Route::get('maternelle','Index_Controller@maternelle');
Route::get('primaire','Index_Controller@primaire');
Route::get('college','Index_Controller@college');
Route::get('lycee','Index_Controller@lycee');

Route::get('pole_art','Index_Controller@pole_art');
Route::get('pole_spo','Index_Controller@pole_spo');
Route::get('pole_culture','Index_Controller@pole_culture');
Route::get('pole_ecologie','Index_Controller@pole_ecologie');
Route::get('presontation','Index_Controller@presontation');
Route::get('equipe_p','Index_Controller@equipe_p');
Route::get('fond','Index_Controller@fond');
Route::get('candidature','Index_Controller@candidature');
Route::get('preinscription','Index_Controller@preinscription');
Route::get('contact','Index_Controller@getContact');
Route::post('contact','Index_Controller@postContact');
Route::get('galarie','Index_Controller@afficher_galery');
Route::get('detail/{id}','Index_Controller@detail');
Route::post('candidature','Index_Controller@Ajouter_Cv');
Route::post('preinscription','Index_Controller@Ajouter_per');
/*End Des Routs de Navigation*/
Route::get('admin','HomeController@index');
/*Start Routs de admin table actualite*/
Route::get('admin/actualite','Actualite_Controler@index');
Route::post('admin/actualite/store','Actualite_Controler@store');
Route::get('admin/actualite/ajouter_art','Actualite_Controler@create');
Route::get('admin/actualite/{id}/edit','Actualite_Controler@edit');
Route::put('admin/actualite/{id}','Actualite_Controler@update');
Route::delete('admin/actualite/{id}','Actualite_Controler@destroy');
/*End Routs de Admin table actualite*/
/*Start Routs de admin table gelarie_m*/
Route::get('admin/galarie_m','Galery_m_Controle@index');
Route::post('admin/galarie_m/store','Galery_m_Controle@store');
Route::get('admin/galarie_m/ajouter_gal','Galery_m_Controle@create');
Route::get('admin/galarie_m/{id}/edit','Galery_m_Controle@edit');
Route::put('admin/galarie_m/{id}','Galery_m_Controle@update');
Route::delete('admin/galarie_m/{id}','Galery_m_Controle@destroy');
/*End Routs de Admin table galerie_m*/
/*Start Routs de admin table gelarie_p*/
Route::get('admin/galarie_p','art@index');
Route::post('admin/galarie_p/store','art@store');
Route::get('admin/galarie_p/ajouter_gal','art@create');
Route::get('admin/galarie_p/{id}/edit','art@edit');
Route::put('admin/galarie_p/{id}','art@update');
Route::delete('admin/galarie_p/{id}','art@destroy');
/*End Routs de Admin table galerie_p*/
/*Start Routs de admin table gelarie_c*/
Route::get('admin/galarie_c','Galery_c_Controle@index');
Route::post('admin/galarie_c/store','Galery_c_Controle@store');
Route::get('admin/galarie_c/ajouter_gal','Galery_c_Controle@create');
Route::get('admin/galarie_c/{id}/edit','Galery_c_Controle@edit');
Route::put('admin/galarie_c/{id}','Galery_c_Controle@update');
Route::delete('admin/galarie_c/{id}','Galery_c_Controle@destroy');
/*End Routs de Admin table galerie_c*/
/*Start Routs de admin table gelarie_p*/
Route::get('admin/galarie_l','Cont_lycee@index');
Route::post('admin/galarie_l/store','Cont_lycee@store');
Route::get('admin/galarie_l/ajouter_gal','Cont_lycee@create');
Route::get('admin/galarie_l/{id}/edit','Cont_lycee@edit');
Route::put('admin/galarie_l/{id}','Cont_lycee@update');
Route::delete('admin/galarie_l/{id}','Cont_lycee@destroy');
/*End Routs de Admin table galerie_p*/
/*Start Routs de admin table pole artistique*/
Route::get('admin/pole_a','Pole_a_Controle@index');
Route::post('admin/pole_a/store','Pole_a_Controle@store');
Route::get('admin/pole_a/ajouter_gal','Pole_a_Controle@create');
Route::get('admin/pole_a/{id}/edit','Pole_a_Controle@edit');
Route::put('admin/pole_a/{id}','Pole_a_Controle@update');
Route::delete('admin/pole_a/{id}','Pole_a_Controle@destroy');
/*End Routs de Admin table pole artistique*/
/*Start Routs de admin table Pole_culturee*/
Route::get('admin/pole_c','Pole_c_Controle@index');
Route::post('admin/pole_c/store','Pole_c_Controle@store');
Route::get('admin/pole_c/ajouter_gal','Pole_c_Controle@create');
Route::get('admin/pole_c/{id}/edit','Pole_c_Controle@edit');
Route::put('admin/pole_c/{id}','Pole_c_Controle@update');
Route::delete('admin/pole_c/{id}','Pole_c_Controle@destroy');
/*End Routs de Admin table Pole_culturee*/
/*Start Routs de admin table pole_ecologie*/
Route::get('admin/pole_e','Pole_e_Controle@index');
Route::post('admin/pole_e/store','Pole_e_Controle@store');
Route::get('admin/pole_e/ajouter_gal','Pole_e_Controle@create');
Route::get('admin/pole_e/{id}/edit','Pole_e_Controle@edit');
Route::put('admin/pole_e/{id}','Pole_e_Controle@update');
Route::delete('admin/pole_e/{id}','Pole_e_Controle@destroy');
/*End Routs de Admin table pole_ecologie*/
/*Start Routs de admin table Pole_sportif*/
Route::get('admin/pole_s','Pole_s_Controle@index');
Route::post('admin/pole_s/store','Pole_s_Controle@store');
Route::get('admin/pole_s/ajouter_gal','Pole_s_Controle@create');
Route::get('admin/pole_s/{id}/edit','Pole_s_Controle@edit');
Route::put('admin/pole_s/{id}','Pole_s_Controle@update');
Route::delete('admin/pole_s/{id}','Pole_s_Controle@destroy');
/*End Routs de Admin table Pole_sportif*/
/*Start Routs de admin table gelarie_p*/
Route::get('admin/candidature','candidature_controller@index');
Route::put('admin/candidature/update_c','candidature_controller@update');
Route::delete('admin/candidature/{id}','candidature_controller@destroy');


Route::get('admin/preinscription','preinscription_controller@index');
Route::put('admin/preinscription/update_p','preinscription_controller@update');
Route::delete('admin/preinscription/{id}','preinscription_controller@destroy');
/*End Routs de Admin table galerie_p*/
Auth::routes();

Route::get('/home', 'HomeController@index1')->name('home');
