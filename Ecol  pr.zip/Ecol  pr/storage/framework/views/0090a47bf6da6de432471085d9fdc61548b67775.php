<?php $__env->startSection('titre'); ?>
Ecol National
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!--Start Slider  bar-->
<!--Start Slider 1 -->
<div class="section">
  
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
  <?php $__currentLoopData = $slider_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($key); ?>" class="active<?php echo e($key == 0 ? 'active' : ''); ?>"></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <?php $__currentLoopData = $slider_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item <?php echo e($key == 0 ? ' active' : ''); ?>">
      <img src="<?php echo e(asset('storage/'.$value->image)); ?>" alt="...">
      <div class="carousel-caption hidden-xs hidden-sm">
     <h1 class="animated fadeInRight"><?php echo e($value->titre_slider); ?></h1>
     <p class="animated fadeInUp"><?php echo e($value->contenu); ?>

</p><br>
<div class="btn btn-primary" id="btn_s" class="animated fadeInRight">LIRE LA SUITE
</div>
      </div>
    </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


</div>
<!-- End slider 1 -->

<!--End   Slidar bar-->
<!--start Actialite  -->
<div class="acti">
  <div class="container">

      <h2 class="text-center">NOS ACTUALITÉS</h2>
    <div class="row">
    <?php $__currentLoopData = $act_index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-4">

              <div class="box">
                <img src="<?php echo e(asset('storage/'.$value->image)); ?>">
                <p class="date">Posté par: <?php echo e(str_limit($value->created_at,10)); ?></p>
                <p class="detail"><?php echo e(str_limit($value->objet,200)); ?>... </p>
                <a href="<?php echo e(url('detail/'.$value->id)); ?>" class="btn btn-primary s">Voir plus...<i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
</a>
              </div>
             
            </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </div>

</div>
<!-- End  Actialite  -->
<!-- Start awsome  -->
<div class="awsom">
  <div class="container">
    <div class="row text-center">
            <div class="col-md-3 ">

              <i class="fa fa-lightbulb-o"></i>
              <p>MANIEL ET INFORMATIQUE</p>
            </div>
            <div class="col-md-3">
              <i class="fa fa-keyboard-o"></i>
              <p>MANIEL ET INFORMATIQUE</p>
            </div>
            <div class="col-md-3">
              <i class="fa fa-calendar-o"></i>
              <p>MANIEL ET INFORMATIQUE</p>
            </div>
            <div class="col-md-3">
              <i class="fa fa-desktop"></i>
              <p>MANIEL ET INFORMATIQUE</p>
            </div>
    </div>
  </div>
</div>
<!--  End awsome -->
<div class="presontation">
  <div class="container">
    <h2>presontation</h2>
    <p>Depuis une décennie, l’Ecole Supérieure de Design et des Arts Visuels/ESDAV a formé plusieurs professionnels dans le monde de l’Architecture d’Intérieur, du Design, du Design Graphique… L’objectif a été de contribuer à développer une excellence du Design marocain, avec des architectes d’intérieur et des Designers conscients des enjeux globaux de leurs pratiques professionnelles et insérant celle-ci dans une ambition d’être les acteurs du changement dans la société. L’Ecole Supérieure de Design et des Arts Visuels a de ce fait développéP une approche élitiste, capable de transférer l’expérience et les méthodes du Design et de l’architecture d’intérieur vers la société marocaine pour générer des nouvelles modalités de management en créant des plateformes de recherches, d’incubation de projets d’innovation et de la formation fondée sur la pensée Design, liée à l’entreprise, aux organismes sociaux institutionnels, collectivités, acteurs territoriaux …</p></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>