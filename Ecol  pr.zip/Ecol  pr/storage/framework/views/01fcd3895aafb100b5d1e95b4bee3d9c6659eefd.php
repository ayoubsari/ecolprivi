<?php $__env->startSection('content_adminn'); ?>
<!-- Start Page index Actualite -->
            <div class="content well">
              <h2>Afficher des Inscriptions </h2>
            </div>
            <div class="clear"></div>
  <table class="table table-bordered table-responsive  table-striped">
  <caption><i class="fa fa-list" aria-hidden="true"></i></caption>
    <tr>
    <th>Nom</th>
    <th>Tel</th> 
    <th>Email</th>
    <th>Nom Enfant</th>
    <th>Message</th>
    <th>date reception</th>
    </tr>
    <?php $__currentLoopData = $gal_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr style="text-align: center;">
      <td><?php echo e($value->nom); ?></td>
      <td><?php echo e($value->numero_tel); ?></td>
      <td><?php echo e($value->Email); ?></td>
      <td><?php echo e($value->nom_enfant); ?></td>
      <td><?php echo e($value->message); ?></td>
      <td><?php echo e(str_limit($value->created_at,10)); ?></td>     
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <center><?php echo e($gal_list->links()); ?></center>
  

<!-- End Page Index Admin -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar_adminn', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>