<?php $__env->startSection('content_admin'); ?>
            <div class="content well">
              <h2>Ajouter des Actualites</h2>
            </div>


<form style="margin:0px 5px;" action="<?php echo e(url('/admin/actualite/store')); ?> " method="post" enctype="multipart/form-data">

			 <?php echo e(csrf_field()); ?>

     <!--Start titre -->
	<div class="form-group <?php if($errors->get('titre')): ?>  has-error  <?php endif; ?>">
	<input type="text" name="titre" placeholder="Titre" class="form-control">

				<?php if($errors->get('titre')): ?>                   
                    <?php $__currentLoopData = $errors->get('titre'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                     <li><?php echo e($message); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>

	</div>
     <!--End titre -->
     <!--Start Objet -->
	<div class="form-group <?php if($errors->get('objet')): ?>  has-error  <?php endif; ?>">
	<textarea name="objet" placeholder="Objet" class="form-control" style="height: 100px;">		
	</textarea>
				<?php if($errors->get('objet')): ?>                   
                    <?php $__currentLoopData = $errors->get('objet'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                     <li><?php echo e($message); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	
    </div>
     <!--End  Objet -->
    <div class="form-group">
				<label for="">Image</label>
				<input type="file" class="form-control" name="ph">
				</div>
	<input type="submit" name="insert" value="Enregistrer" class="btn btn-primary">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>