<!-- Start title -->
<?php $__env->startSection('titre'); ?>
Details
<?php $__env->stopSection(); ?>
<!-- End Title  -->
<?php $__env->startSection('content'); ?>
<div class="cover maternelle">
      <div class="container">
     <h2>Actualites</h2>
      </div>
</div>
<div class="detail">
	<div class="container">
		<div class="row">
					<div class="col-md-8">
					<h3><?php echo e($act->titre); ?></h3>
					<div class="date_p">
					Posté par: <?php echo e(str_limit($act->created_at,10)); ?>

					</div>
					<a  href="">
					<img src="<?php echo e(asset('storage/'.$act->image)); ?>">
					</a>
					<p>
					<?php echo e($act->objet); ?>

					</p>
					<a href="<?php echo e(url('/')); ?>" class="btn btn-primary" style="margin-bottom: 20px;">Retour</a>
					</div>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<!-- Start Details -->


<!-- End Detials -->
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>