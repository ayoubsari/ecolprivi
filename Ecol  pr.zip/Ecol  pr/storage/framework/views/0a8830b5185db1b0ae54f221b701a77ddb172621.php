<?php $__env->startSection('titre'); ?>
Equipe pédagogique
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<!--Start cover -->
<div class="cover maternelle">
      <div class="container">
     <h2>Equipe pédagogique</h2>
      </div>
</div>
<!--End cover -->
<!--Start page maternelle -->
<div class="cycle">
  <div class="container">
    <div class="row">
          <div class="col-md-3">
            <ul class="menu_verticale">
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a  href="presontation.html" >Présentation</a></li>
              <li><i class="fa fa-arrow-right act_m" aria-hidden="true"></i><a class="act_m" href="equipe_p.html">Equipe pédagogique</a></li>
               <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="fond.html">Mot du fondateur</a></li>
            </ul>
           <div class="carre cover">
             <h1 class="text-center">Equipe pédagogique</h1>
            <center> <img src="<?php echo e(asset('assets\img\logo.png')); ?>" width="150" height="250"   /></center>
            <h3 class="text-center">Exposé Alimentation</h3>
             
           </div>
        </div>
      <div class="col-md-9">
                <div class="menu_top">

                      <ul>
                        <li><a href="">Accueil</a>></li>
                        <li>Equipe pédagogique</li>
 
                      </ul>

                  
                </div>
        <div class="clear"></div>
        <h2 class="pre text-center">Notre équipe</h2>
        <p class="para_m">Notre équipe pédagogique est composée de professeurs diplômés et agréés par le Ministère de l’Education Nationale, ainsi que de professeurs étrangers affiliés, apportant ainsi une diversité et une culture propre à favoriser l’ouverture à un environnement interculturel.
</p>
<p class="para_m">Nos enseignant(e)s de la maternelle, du primaire et du collège bénéficient d’une formation continue au sein de l’établissement par des intervenants locaux et nationaux.</p>


<p class="para_m">Des formateurs de l’Université d’Helsinki sont présents régulièrement pour insuffler une dynamique propre à la philosophie de l’école.</p>
<p class="para_m">Les différents cycles du groupe sont encadrés par une équipe expérimentée et au faite de toutes les innovations pédagogiques.</p>




<div class="fts" style="padding: 20px;">
</div>

              <!-- Start Images page -->
              <img src="<?php echo e(asset('assets\img\sec7.jpg')); ?>" style="width: 100%">
              <!-- End Images pages -->

<div class="fts" style="padding: 70px;">
</div>
    
    </div>
    </div>
    </div>
    </div>
<!-- end page maternelle -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>