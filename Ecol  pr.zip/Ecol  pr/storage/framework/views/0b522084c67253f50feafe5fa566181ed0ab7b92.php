<?php $__env->startSection('content_admin'); ?>
            <div class="content well">
              <h2>Bienvenu Administrateur</h2>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>