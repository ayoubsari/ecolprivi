<?php $__env->startSection('titre'); ?>
Derecteur
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="heading">
<div class="container">
	<h2>Mote De  Directeur de Ecol</h2>
</div>
</div>
<div class="p_derecteur">
<div class="container">
<div class="row">
	<div class="col-md-8  ">
			<p>
Ecole Nationale des Sciences Appliquées de Safi dispose d'un potentiel humain qualifié dans divers domaines tels que Génie Industriel et Génie Informatique. L'école est consciente de l'importance que doit revêtir le rapprochement entre la recherche scientifique et le monde de l'entreprise. Pour permettre ce rapprochement il faut encourager l'existence d'un environnement favorable à cette collaboration et inciter le transfert du savoir entre les écoles d'ingénieurs et les entreprises et ce dans le but de renforcer des relations de coopération et de partenariat avec le tissu socio-économique de la région Abda-Doukkala. L'ENSAS compte servir de levier et de soutien pour le développement des technologies en jouant un rôle majeur d'expertise, de veille technologique, de réflexion, de support et de conseil pour le secteur public et privé ainsi que pour les opérateurs économiques de la région. L'implication des entreprises dans cet objectif est fortement encouragée et souhaitée de manière à créer des conditions favorables au développement de l'innovation technologique.
servir de levier et de soutien pour le développement des technologies en jouant un rôle majeur d'expertise, de veille technologique, de réflexion, de support et de conseil pour le secteur public et privé ainsi que pour les opérateurs économiques de la région. L'implication des entreprises dans cet objectif est fortement encouragée et souhaitée de manière à créer des conditions favorables au développement de l'innovation 
servir de levier et de soutien pour le développement des technologies en jouant un rôle majeur d'expertise, de veille technologique, de réflexion, de support et de conseil pour le secteur public et privé ainsi que pour les opérateurs économiques de la région. L'implication des entreprises dans cet objectif est fortement encouragée et souhaitée de manière à créer des conditions favorables au développement de l'innovationtechnologique.
Ahmed DERJA<br>
Directeur de l'ENSA-SAFI
			</p>
	</div>
	<div class="col-md-4 "><img src="<?php echo e(asset('assets\img\derja.jpg')); ?>" alt="Image de derecteur"  /></div>
</div>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>