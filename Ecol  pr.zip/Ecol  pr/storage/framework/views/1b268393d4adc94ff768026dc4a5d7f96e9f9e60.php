<?php $__env->startSection('titre'); ?>
Maternelle
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>

<!--Start cover -->
<div class="cover maternelle">
      <div class="container">
     <h2>Maternelle</h2>
      </div>
</div>
<!--End cover -->
<!--Start page maternelle -->
<div class="cycle">
  <div class="container">
    <div class="row">
          <div class="col-md-3">
            <ul class="menu_verticale">
              
              <li><i class="fa fa-arrow-right act_m" aria-hidden="true"></i><a href="<?php echo e(url('/maternelle')); ?>" class="act_m" >Maternelle</a></li>
              <li><i class="fa fa-arrow-right " aria-hidden="true"></i><a href="<?php echo e(url('/primaire')); ?>">Primaire</a></li>
              <li><i class="fa fa-arrow-right " aria-hidden="true"></i><a href="<?php echo e(url('/college')); ?>" >Collège</a></li>
              <li><i class="fa fa-arrow-right" aria-hidden="true"></i><a href="<?php echo e(url('/lycee')); ?>">Lycée</a></li>
            </ul>
           <div class="carre cover">
             <h1 class="text-center">Meternelle</h1>
            <center> <img src="<?php echo e(asset('assets\img\sec4.jpg')); ?>"  width="150" height="250"   /></center>
            <h3 class="text-center">Exposé Alimentation</h3>
             
           </div>
        </div>
      <div class="col-md-9">
                <div class="menu_top">

                      <ul>
                        <li><a href="">Accueil</a>></li>
                        <li><a href="">Cycles</a>></li>
                        <li>Maternelle</li>
                      </ul>

                  
                </div>
        <div class="clear"></div>
        <h2 class="pre">Présentation</h2>
        <p class="para_m">L’enseignement de la maternelle est essentiel dans le cursus scolaire d’un enfant. C’est pendant cette période qu’il va faire ses « premiers pas » à la découverte du monde et de lui-même. La mission de l’enseignant : favoriser toutes les situations qui permettront à l’élève : De se développer harmonieusement dans un milieu adapté, sécurisant et riche.</p>
        <p class="para_m">Le jeu est un élément primordial et un outil que l’enseignant va utiliser pour conduire l’enfant vers la connaissance :</p>
        <ul class="apprendre">
          <li>apprendre à s’exprimer, et à vivre avec les autres</li>
          <li>à réfléchir, et à développer ses capacités motrices, sensorielles et créatives</li>
          <li>à acquérir des techniques pour aborder des apprentissages essentiels comme la lecture et l’écriture.</li>

        </ul>
              <div class="inscri_m cover">
              <div class="row">
                <div class="col-md-6">
                   <h2>Maternelle</h2>
                   <p>Jeunes enfants à partir de 2 ans</p>
                </div>
               <div class="col-md-6">
                  <a href="<?php echo e(url('/preinscription')); ?>" class="pull-right"><i class="fa fa-file-text-o"></i>S'inscrire</a>
                </div>
              </div>
               
              </div>
<!--Start Slider-->
<div id="carousel" class="carousel slide sliderr" data-ride="carousel">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <?php $__currentLoopData = $gal_l; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item <?php echo e($key == 0 ? ' active' : ''); ?>">
      <img src="<?php echo e(asset('storage/'.$value->url_image)); ?>" class="img-responsive">
     
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <!-- Controls -->
  <a class="left carousel-control hiden-xs" href="#carousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control hiden-xs" href="#carousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<div id="carousel-thumbs" class="carousel slide slidee">
  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <?php $__currentLoopData = $gal_m; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-xs-3 <?php echo e($key == 0 ? ' active' : ''); ?>"onclick="$('#carousel').carousel(<?php echo e($key); ?>);">
        <img src="<?php echo e(asset('storage/'.$value->url_image)); ?>" class="img-responsive">
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
<!-- Controls -->
  </div>
</div>
<!-- End Slider -->
<br><br><br>
              <!-- Start Menu page -->
         <div class="menu_pédagie">
                <ul class="list-unstyled list-menu">
                  <li class="act_color" data-class="one">Objectif</li>
                  <li data-class="two">pédagogie</li>
                  <li data-class="three">Activités</li>
                  <li data-class="for">Equipements</li>
                </ul>
                <div  class="clear"> </div>
                        <div class="tabs_content">
                        <div class="one">
                        <p>La maternelle accueille les enfants de 2 à 6 ans..</p>
                        <p>Elle a pour mission le développement cognitif, sensoriel et affectif du jeune enfant. C’est à cette période de la vie que l’enfant fait « ses premiers pas » à la découverte de lui-même et du monde.</p>
                        <p>Le jeu est un élément naturel et essentiel ; un outil que l’enseignant va utiliser pour conduire son projet pédagogique et accompagner l’enfant dans ses apprentissages.</p>
                        <p>A travers les cinq domaines de compétence, l’école maternelle a pour objectifs de :</p>
                        <ul class="list-contenu">
                          <li>Développer l’envie et le plaisir d’apprendre.</li>
                          <li>Assurer la maîtrise du langage.</li>
                          <li>Préparer l’accès aux apprentissages fondamentaux.</li>
                        </ul>
                        <p>Au groupe scolaire Benabdallah, nous pratiquons la pédagogie de projets qui implique activement le jeune élève. En maternelle, tout est prétexte aux apprentissages, toutes les situations sont exploitées pour atteindre notre objectif : l’épanouissement « tout azimut » de l’enfant qu’il soit personnel, social, intellectuel, artistique ou culturel.</p>
                        </div>
                        <div class="two">
                         <p> La Maternelle du groupe scolaire Benabdallah à Marrakech, propose une pédagogie alternative :</p>
                         <ul class="list-contenu">
                           <li>Suivi individualisé de l’enfant tout au long du cycle</li>
                           <li>Enseignement bilingue : français /arabe</li>
                           <li>Initiation à l’anglais dès la moyenne section</li>
                           <li>Développement de l’autonomie</li>
                           <li>Formation continue des enseignants</li>
                           <li>2 éducatrices par classe</li>
                           <li>24 élèves maximum par classe</li>
                           <li>Intervenants spécialisés</li>
                           <li>Sensibilisation au respect de l’environnement</li>
                         </ul>
                        </div>
                        <div class="three">
                          <p>La Maternelle du groupe scolaire Benabdallah à Marrakech, intègre dans le programme l’initiation aux activités suivante :</p>
                          <ul class="list-contenu">
                            <li>Art plastique : expérimentation des différentes techniques, développement de la créativité</li>
                            <li>Expression corporelle par le théâtre et la danse</li>
                            <li>Eveil musical</li>
                            <li>Psychomotricité</li>
                            <li>Ateliers découverte ( Equitation, Cirque…)</li>
                          </ul>
                        </div>
                        <div class="for">
                          <p>La Maternelle du groupe scolaire Benabdallah à Marrakech, dispose de :</p>
                          <ul class="list-contenu">
                            <li>Salle de psychomotricité</li>
                            <li>Salle d’arts</li>
                            <li>Médiathèque des petits</li>
                            <li>Ferme et jardin pédagogiques</li>
                            <li>Aire de jeux de plein air</li>
                            <li>Vidéo-surveillance</li>
                            <li>Réfectoire équipé</li>
                            <li>Matériel éducatif Nathan</li>
                          </ul>
                        </div>
                        </div>
          </div>

    
    </div>
    </div>
    </div>
    </div>
<!-- end page maternelle -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>