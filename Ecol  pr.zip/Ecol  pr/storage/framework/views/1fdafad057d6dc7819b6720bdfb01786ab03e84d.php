<?php $__env->startSection('content_adminn'); ?>
<!-- Start Page index Actualite -->
            <div class="content well">
              <h2>Gestion des Slider</h2>
            </div>
            <div class="clear"></div>
            <?php echo $__env->make('part.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <button type="button" class="btn btn-primary bs" data-toggle="modal" data-target="#myModal"  style="font-weight: bold;margin-bottom: 5px"><i class="fa fa-plus" aria-hidden="true"></i> Ajouter Slider</button>
  <table class="table table-bordered table-responsive  table-striped">
  <caption><i class="fa fa-list" aria-hidden="true"></i></caption>
    <tr>
    <th>Images</th>
    <th>Titre</th> 
    <th>Contenu</th>
    <th>date</th>
    <th>Operation</th>
    </tr>
    <?php $__currentLoopData = $slider_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td ><img src="<?php echo e(asset('storage/'.$value->image)); ?>" width="220" alt="..." height="100"></td>
      <td><?php echo e($value->titre_slider); ?></td>
      <td style="width: 250px"><p style="text-align: justify;"><?php echo e($value->contenu); ?></p></td>
      <td><?php echo e(str_limit($value->created_at,10)); ?></td>
     <td>
      <!-- Start Supprimer -->
  
  <div class="modal fade" id="modal-delete" tabIndex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">
            ×
          </button>
          <h4 class="modal-title">Confirmer Supprimer</h4>
        </div>
        <div class="modal-body">
          <p class="lead">
            <i class="fa fa-question-circle fa-lg"></i>  
            Voulez vous Supprimer?
          </p>
        </div>
        <div class="modal-footer">
          <form   action="<?php echo e(url('admin/slider/'.$value->id)); ?>"  method="post">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('DELETE')); ?>

          <button type="submit" class="btn btn-primary">
          <i class="fa fa-trash-o"></i> Oui
          </button>
          <button type="button" class="btn btn-danger"
          data-dismiss="modal"><i class="fa fa-times-circle"></i> Annuler</button>

          </form>
        </div>
      </div>
    </div>
    </div>
<!-- End Supprimer-->
      <a href="<?php echo e(url('admin/slider/'.$value->id.'/edit')); ?>" class="btn btn-small btn btn-primary"><i class="fa fa-refresh"></i> Modifier</a>

      <button type="button" class="btn btn-small btn-danger" data-toggle="modal" data-target="#modal-delete" ><i class="fa fa-trash-o"></i> Supprimer</button>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <center><?php echo e($slider_list->links()); ?></center>
  

 <!-- Start Model Ajouter-->
<!-- Trigger the modal with a button -->

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Ajouter nouvelle Actualite</h4>
        </div>
        <div class="modal-body">
          <form style="margin:0px 5px;" action="<?php echo e(url('/admin/slider/store')); ?> " method="post" enctype="multipart/form-data">

       <?php echo e(csrf_field()); ?>

     <!--Start titre -->
     
  <div class="form-group">
  <input type="text" name="titre_slider" placeholder="Titre Slider" class="form-control">



  </div>
     <!--End titre -->
     <!--Start Objet -->
  <div class="form-group">
  <textarea name="contenu_slider" placeholder="contenu" class="form-control" style="height: 100px;"></textarea>
  </div>
     <!--End  Objet -->
    <div class="form-group">
        <label for="">Image</label>
        <input type="file" class="form-control" name="ph">
    </div>
  <button type="submit" class="btn btn-primary">
    <i class="fa fa-floppy-o" aria-hidden="true"></i> Enregistrer
  </button>
  <button type="button" class="btn btn-danger pull-right" data-dismiss="modal">
  <i class="fa fa-times-circle" aria-hidden="true"></i> Anuller</button>
</form>
        </div>
      </div>
      
    </div>
  </div>

<!-- End  Model Ajouter-->
<!-- End Page Index Admin -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar_adminn', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>