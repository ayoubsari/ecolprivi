<!--  Start de Title  -->
<?php $__env->startSection('titre'); ?>
Contact
<?php $__env->stopSection(); ?>
<!--  End de Title  -->
<?php $__env->startSection('content'); ?>
<!-- Start Contact  -->
<div class="contact">
  <div class="container">
  <h2 class="text-center">CONTACT</h2>
    <div class="row">

      <div class="col-md-6">
    <h3>Contact Information</h3> 
    <div class="adress_c"> 
    <p><i class="fa fa-map-marker" aria-hidden="true"></i>
392, Rue Mustapha El Mâani, Casablanca</p>  
    <p><i class="fa fa-phone" aria-hidden="true"></i>
(+212)(0) 5 22 49 00 08</p>  
</div>
    <!-- Start form contact -->
<div class="conetnu1">
<ul class="list-unstyled">
  <li class="style_css" data-class="one"><i class="fa fa-envelope" aria-hidden="true"></i></li>
  <li data-class="two"><i class="fa fa-map-marker" aria-hidden="true"></i> </li>
  <li data-class="three"><i class="fa fa-phone"" aria-hidden="true"></i></li>
</ul>
<div  class="clear"> </div>
<div class="tabs_content">
<div class="one">
  <form action="<?php echo e(url('contact')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <input type="text" name="subject" placeholder="Subjet" class="form-control" required >
    <input type="email" name="email" placeholder="Votre email" class="form-control" required >

    <textarea class="form-control" placeholder="Message" height="150"  name="message" required ></textarea>
    <button class="btn btn-primary" type="submit"><i class="fa fa-paper-plane" aria-hidden="true" ></i>  Envoyer</button>
  </form>
</div>

<div class="two ">
  <h3>Adresse</h3>
<p><i class="fa fa-map-marker" aria-hidden="true"></i>
392, Rue Mustapha El Mâani, Casablanca</p>  
<p><i class="fa fa-map-marker" aria-hidden="true"></i>
34, Av. Omar Ibn Khattab Agdal, Rabat</p>  


</div>


<div class="three ">
<h3>Telephone</h3>
<p><i class="fa fa-phone" aria-hidden="true"></i>
(+212)(0) 5 22 49 00 08</p>  
<p><i class="fa fa-phone" aria-hidden="true"></i>
(+212)(0) 6 22 49 00 08</p>  
<p><i class="fa fa-whatsapp" aria-hidden="true"></i> (+212)(0) 6 49 26 46 42</p>
</div>
</div>
<div class="message_f">
<center><?php echo $__env->make('part.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>; </center>
</div>
</div>
    <!--End form contact -->

      </div>
      <div class="col-md-6">
    <h3>Trouvez Nous On Map</h3> 
    <div style="height:401px;width: 100%">
<script src='https://maps.googleapis.com/maps/api/js?v=3.exp'></script><div style='overflow:hidden;'><div id='gmap_canvas' style='height:401px;width:100%;'></div><div></div><div></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div><script type='text/javascript'>function init_map(){var myOptions = {zoom:16,center:new google.maps.LatLng(32.29405194365084,-9.225352575779654),mapTypeId: google.maps.MapTypeId.TERRAIN};map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(32.29405194365084,-9.225352575779654)});infowindow = new google.maps.InfoWindow({content:'<strong><i class="fa fa-map-marker"></i> Ecol Privi</strong><br>safi<br>'});google.maps.event.addListener(marker, 'click', function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
    </div>       
      </div>
    </div>
  </div>
</div>

<!-- End Contact -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>