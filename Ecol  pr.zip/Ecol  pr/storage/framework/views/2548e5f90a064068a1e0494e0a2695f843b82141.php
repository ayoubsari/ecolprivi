<!DOCTYPE html>
<html>
<head>
  <title>Contact</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="<?php echo e(asset('assets\img\logoe.ico')); ?>"/>
<link href="https://fonts.googleapis.com/css?family=Dosis|Leckerli+One" rel="stylesheet">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\bootstrap.min.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\font-awesome.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\normalize.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\style.css')); ?>">
<link href="https://fonts.googleapis.com/css?family=Dosis|Leckerli+One" rel="stylesheet">
</head>

<body>
<!-- Start navbar -->
<nav class="navbar navbar-default">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
            <span class="navbar-brand" >
    
</span>
      <img  src="<?php echo e(asset('assets\img\logo.png')); ?>" 
      style="width: 100px;height: 65px;    padding-top: 1px;">

    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo e(url('/')); ?>">ACCUEIL</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">CYCLES <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo e(url('/maternelle')); ?>">Maternelle</a></li>
            <li><a href="<?php echo e(url('/primaire')); ?>">Primaire</a></li>
            <li><a href="<?php echo e(url('/college')); ?>">Collége</a></li>
            <li><a href="<?php echo e(url('/lycee')); ?>">Lycée</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">PÔLES D’ ACTIVITES <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo e(url('/pole_art')); ?>">Pôle Artistique</a></li>
            <li><a href="<?php echo e(url('/pole_spo')); ?>">Pôle Sportif</a></li>
            <li><a href="<?php echo e(url('/pole_culture')); ?>">Pôle Culturel</a></li>
            <li><a href="<?php echo e(url('/pole_ecologie')); ?>">Pôle Ecologie</a></li>          
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">A PROPROS DE NOUS <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo e(url('/presontation')); ?>">Présentation</a></li>
            <li><a href="<?php echo e(url('/equipe_p')); ?>">Equipe pédagogique</a></li>
            <li><a href="<?php echo e(url('/fond')); ?>">Mot du fondateur</a></li>
          </ul>
        </li>
        <li><a href="<?php echo e(url('/contact')); ?>">CONTACT</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<!-- End navbar -->
<!-- Start Contact  -->
<!--Start cover -->
<div class="cover maternelle">
      <div class="container">
     <h2>Contact</h2>
      </div>
</div>
<!--End cover -->
<div class="contact">
  <div class="container">
    <div class="row">

      <div class="col-md-6">
    <h3>Contact Information</h3> 
    <div class="adress_c"> 
    <p><i class="fa fa-map-marker" aria-hidden="true"></i>
392, Rue Mustapha El Mâani, Casablanca</p>  
    <p><i class="fa fa-phone" aria-hidden="true"></i>
(+212)(0) 5 22 49 00 08</p>  
</div>
    <!-- Start form contact -->
<div class="conetnu1">
<ul class="list-unstyled">
  <li class="style_css" data-class="one"><i class="fa fa-envelope" aria-hidden="true"></i></li>
  <li data-class="two"><i class="fa fa-map-marker" aria-hidden="true"></i> </li>
  <li data-class="three"><i class="fa fa-phone"" aria-hidden="true"></i></li>
</ul>
<div  class="clear"> </div>
<div class="tabs_content">
<div class="one">
  <form action="<?php echo e(url('contact')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <input type="text" name="subject" placeholder="Subjet" class="form-control" required 
    data-toggle="p" data-content="Enter le Nom s'il vous plais"  id="user_nom" data-placement="bottom" required>
    <input type="email" name="email" placeholder="Votre email" class="form-control" required 
    data-toggle="em" data-content="Enter le email est bien valider exmepl: ayoub56@gmail.com" id="user_email" data-placement="bottom" required>

    <textarea class="form-control" placeholder="Message" height="150"  name="message" required 
    data-toggle="prm" data-content="Enter le Message s'il vous plais"  data-placement="bottom" id="user_message" required></textarea>
    <button class="btn btn-primary" type="submit"><i class="fa fa-paper-plane" aria-hidden="true" ></i>  Envoyer</button>
  </form>
</div>

<div class="two ">
  <h3>Adresse</h3>
<p><i class="fa fa-map-marker" aria-hidden="true"></i>
392, Rue Mustapha El Mâani, Casablanca</p>  
<p><i class="fa fa-map-marker" aria-hidden="true"></i>
34, Av. Omar Ibn Khattab Agdal, Rabat</p>  


</div>


<div class="three ">
<h3>Telephone</h3>
<p><i class="fa fa-phone" aria-hidden="true"></i>
(+212)(0) 5 22 49 00 08</p>  
<p><i class="fa fa-phone" aria-hidden="true"></i>
(+212)(0) 6 22 49 00 08</p>  
<p><i class="fa fa-whatsapp" aria-hidden="true"></i> (+212)(0) 6 49 26 46 42</p>
</div>
</div>
<div class="message_f">
<center><?php echo $__env->make('part.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>; </center>
</div>
</div>
    <!--End form contact -->

      </div>
      <div class="col-md-6">
    <h3>Trouvez Nous On Map</h3> 
    <div style="height:401px;width: 100%">
<script src='https://maps.googleapis.com/maps/api/js?v=3.exp'></script><div style='overflow:hidden;'><div id='gmap_canvas' style='height:401px;width:100%;'></div><div></div><div></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div><script type='text/javascript'>function init_map(){var myOptions = {zoom:16,center:new google.maps.LatLng(32.29405194365084,-9.225352575779654),mapTypeId: google.maps.MapTypeId.TERRAIN};map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(32.29405194365084,-9.225352575779654)});infowindow = new google.maps.InfoWindow({content:'<strong><i class="fa fa-map-marker"></i> Ecol Privi</strong><br>safi<br>'});google.maps.event.addListener(marker, 'click', function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
    </div>       
      </div>
    </div>
  </div>
</div>

<!-- End Contact -->



<!-- Start  Footer -->
<div class="footer">
<div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12">
          <h3>Contact</h3>
          <p>Adresse : Angle Boulevard Tantan et rue Bengeurir G.H.N° 4 Almanar Anfa Casablanca 20160 Maroc</p>
        </div>
        <div class="col-md-4 col-sm-6 col-xs-12">
          <h3>Réseaux sociaux</h3>
                <div class="icon">
                  <a  href="" target="_blank"><i class="fa fa-facebook"></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-twitter "></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-google-plus"></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-linkedin"></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-youtube"></i></a>
                 </div>
        </div>
        <div class="col-md-4 col-sm-6 col-xs col-xs-12">
          <h3>Mots clés</h3>
          <p>Ecole, Architecture d'intérieur, Casablanca, Maroc, Design, Design d'objets, Design Graphique, Digital, Formation accréditée, Enseignement supérieur,</p>
        </div>
      </div>
</div>
</div>
<div class="pied">
  <p class="text-center">Copyrights © Développer By<a style="text-decoration: none;color:black;font-weight: bold;" href="http://www.devosystem.com" target="_blank"> Ayoub Sabri </a><span id="date_m"></span></p></div>
<!-- End  Fotter -->
<!--Start Flesh-->
<span class="flech">
  <i class="fa fa-angle-up" aria-hidden="true"></i>
</span>
<!-- End Flesh -->
<script src="<?php echo e(asset('assets\js\jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets\js\bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets\js\validate_contact_page.js')); ?>"></script>
</body>
</html>
