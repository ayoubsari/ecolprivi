<?php $__env->startSection('titre'); ?>
Galarie
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="galarie">
	<div class="container">
	<h2>GALERIE</h2>
		<div class="row">
			<div class="col-md-3 col-sm-6">
               <a href="<?php echo e(asset('assets\img\im\box1.jpg')); ?>" ><img src="<?php echo e(asset('assets\img\im\box1.jpg')); ?>">
               </a>
			</div>
			<div class="col-md-3 col-sm-6">
               <a href=""><img src="<?php echo e(asset('assets\img\im\box2.png')); ?>">
               </a>
			</div>
			<div class="col-md-3 col-sm-6">
               <a href=""><img src="<?php echo e(asset('assets\img\im\box3.png')); ?>">
               </a>
			</div>
			<div class="col-md-3 col-sm-6">
               <a href=""><img src="<?php echo e(asset('assets\img\im\box1.jpg')); ?>">
               </a>
			</div>
		</div>
		<div class="row">
			<div class="col-md-3 col-sm-6">
               <a href=""><img src="<?php echo e(asset('assets\img\im\box1.jpg')); ?>">
               </a>
			</div>
			<div class="col-md-3 col-sm-6">
               <a href=""><img src="<?php echo e(asset('assets\img\im\box2.png')); ?>">
               </a>
			</div>
			<div class="col-md-3 col-sm-6">
               <a href=""><img src="<?php echo e(asset('assets\img\im\box3.png')); ?>">
               </a>
			</div>
			<div class="col-md-3 col-sm-6">
               <a href=""><img src="<?php echo e(asset('assets\img\im\box1.jpg')); ?>">
               </a>
			</div>
		</div>
		<div class="row">
			<div class="col-md-3 col-sm-6">
               <a href=""><img src="<?php echo e(asset('assets\img\im\box1.jpg')); ?>">
               </a>
			</div>
			<div class="col-md-3  col-sm-6" >
               <a href=""><img src="<?php echo e(asset('assets\img\im\box2.png')); ?>">
               </a>
			</div>
			<div class="col-md-3  col-sm-6">
               <a href=""><img src="<?php echo e(asset('assets\img\im\box3.png')); ?>">
               </a>
			</div>
			<div class="col-md-3 col-sm-6">
               <a href=""><img src="<?php echo e(asset('assets\img\im\box1.jpg')); ?>">
               </a>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>