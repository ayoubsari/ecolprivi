<?php $__env->startSection('content_adminn'); ?>
            <div class="content well">
              <h2>Modifier  des Actualites</h2>
            </div>


<form style="margin:0px 5px;" action="<?php echo e(url('admin/actualite/'.$act->id)); ?> " method="post" enctype="multipart/form-data">
<input type="hidden" name="_method" value="PUT">
			 <?php echo e(csrf_field()); ?>

     <!--Start titre -->
	<div class="form-group <?php if($errors->get('titre')): ?>  has-error  <?php endif; ?>">
	<input type="text" name="titre" placeholder="Titre" class="form-control" value="<?php echo e($act->titre); ?>">
				<?php if($errors->get('titre')): ?>                   
                    <?php $__currentLoopData = $errors->get('titre'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                     <li><?php echo e($message); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
	</div>
     <!--End titre -->
     <!--Start Objet -->
	<div class="form-group <?php if($errors->get('objet')): ?>  has-error  <?php endif; ?>">
	<textarea name="objet" placeholder="Objet" class="form-control" style="height: 100px;"><?php echo e($act->objet); ?></textarea>
				<?php if($errors->get('objet')): ?>                   
                    <?php $__currentLoopData = $errors->get('objet'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                     <li><?php echo e($message); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	
    </div>
     <!--End  Objet -->
    <div class="form-group">
				<label for="">Image</label>
				<input type="file" class="form-control" name="ph">
				</div>
    <button type="submit" class="btn btn-primary">
        <i class="fa fa-refresh"></i> Modifier
    </button>
	
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar_adminn', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>