<?php $__env->startSection('content_admin'); ?>
            <div class="content well">
              <h2>Ajouter des Galaries</h2>
            </div>


<form style="margin:0px 5px;" action="<?php echo e(url('/admin/galarie/store')); ?> " method="post" enctype="multipart/form-data">

			 <?php echo e(csrf_field()); ?>

    <div class="form-group">
				<label for="">Image</label>
				<input type="file" class="form-control" name="phs">
				</div>
	<input type="submit" name="insert" value="Enregistrer" class="btn btn-primary">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>