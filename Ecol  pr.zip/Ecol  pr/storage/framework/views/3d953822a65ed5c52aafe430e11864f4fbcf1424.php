<?php $__env->startSection('titre'); ?>
Actualite
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Start Des Formations-->
<div class="formation">
  <div class="container">

            <?php $__currentLoopData = $act_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="box_formation">
              <h3><?php echo e($value->titre); ?></h3>

              <div class="date_p">
                Posté par: <?php echo e(str_limit($value->created_at,10)); ?>

              </div>
              <div class="row">

                <div class="col-md-3 col-sm-3 col-xs-12">
                  <img src="<?php echo e(asset('storage/'.$value->image)); ?>" style="width: 100%;
            height: 128px;" >
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <p><?php echo e(str_limit($value->objet,310)); ?>(...) </p>
                  <a href="<?php echo e(url('detail/'.$value->id)); ?>" class="btn btn-primary" >Voir plus...<i class="fa fa-chevron-circle-right"></i></a>
                </div>
              </div>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

 <center> <?php echo e($act_list->links()); ?>  </center>
</div>
<!-- End Des Formations-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>