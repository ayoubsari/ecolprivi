<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title></title>
<link rel="shortcut icon" href="<?php echo e(asset('assets\img\ensa.ico')); ?>"/>
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\bootstrap.min.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\font-awesome.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\style1.css')); ?>">
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular-route.js"></script>
<link rel="stylesheet" type="text/css" href="style1.css">
<style type="text/css">
  .nav-pills li a:hover{
  background-color: #337AB7;
  }
</style>
</head>
<body ng-app>
    <div class="brand">
      <ul class="nav_bar pull-right">
                              <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                         
                        <?php else: ?>
                            <li>
                                 <i class="fa fa-user" aria-hidden="true"></i>   <?php echo e(Auth::user()->name); ?> 
                            </li>
                            <li>
                    <a href="<?php echo e(route('login')); ?>" 
                    onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();"
                            ><i class="fa fa-sign-out fa-fw"></i>Deconnecte</a>
                            </li>
                     <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                     <?php echo e(csrf_field()); ?>

                      </form>
                        <?php endif; ?>
      </ul>
    </div>
    <div class="contenu">
    <div class="row">
        <div class="col-md-3">

            <ul class="nav nav-pills nav-stacked">
            <li><h2 style="    margin-left: 98px;font-weight: bold;text-transform: uppercase;font-size: 44px;">Admin</h2></li>
                 <div class="logo"><img style="    width: 100%;height: 183px;" src="<?php echo e(asset('assets\img\Admin-icon.png')); ?>"></div>
                <li class="active"><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-home fa-fw"></i>Tableau de bord</a></li>
                <li><a href="<?php echo e(url('admin/actualite')); ?>"><i class="fa fa-list-alt fa-fw"></i>Gestion de Actualite</a></li>
                <li><a href="<?php echo e(url('admin/galarie')); ?>"><i class="fa fa-picture-o fa-fw"></i>Gestion de Galery</a></li>
                <li><a href="<?php echo e(url('admin/slider')); ?>"><i class="fa fa-bar-chart-o fa-fw"></i>Gestion de Slider</a></li>
                <li><a href=""><i class="fa fa-tasks fa-fw"></i>Forms</a></li>
                <li><a href=""><i class="fa fa-calendar fa-fw"></i>Calender</a></li>
                <li><a href=""><i class="fa fa-book fa-fw"></i>Library</a></li>
                <li><a href=""><i class="fa fa-sign-out fa-fw"></i>Deconnecte</a></li>
            </ul>
        </div>
        <div class="col-md-9 ">

         
            <!-- Start Content page admin-->
         <?php echo $__env->yieldContent('content_admin'); ?>
            <!-- End Content page admin -->

        </div>
    </div>
    </div>

<!-- Start  Footer -->
<footer id="ft">
<div class="container">
<div class="row">
<div class="col-lg-5 col-md-5 col-sm-5 col-xm-12">
<p id="copyr">Copyright © Développer By <a href="">AYOUB SABRI</a><span id="date"></span> </p>
</div>s
<div class="col-lg-7 col-md-7 col-sm-7 col-xm-12">    
     <ul id="icon" class="text-center pull-right">
      <li style="color:gray;font-size:14px;">Ecole les réseaux sociaux</li>
      <li>  <a href="" id="f"><i class="fa fa-facebook"></i></a></li>
    <li>  <a href="facebook.com" target="_blank" id="t"><i class="fa fa-twitter "></i></a></li>
        <li>  <a href="" id="p"><i class="  fa fa-google-plus"></i></a></li> 
           <li>  <a href="" id="s"><i class="fa fa-dribbble"></i></a></li> 
    <li>  <a href="" id="w"><i class="fa fa-skype"></i></a></li>
 
  </ul>
    
    
</div>
</div>
</footer>
<!-- End  Fotter -->
<!--Start Flesh-->
<span class="flech">
  <i class="fa fa-angle-up" aria-hidden="true"></i>
</span>
<!-- End Flesh -->
<script type="text/javascript"></script>
<script src="<?php echo e(asset('assets\js\jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets\js\bootstrap.min.js')); ?>"></script>
</body>
</html>