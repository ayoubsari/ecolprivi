<h3>You Have a New Contact Via the Contact Form</h3>

<div>
	<?php echo e($message); ?>

</div>

<p>Sent via <?php echo e($email); ?></p>