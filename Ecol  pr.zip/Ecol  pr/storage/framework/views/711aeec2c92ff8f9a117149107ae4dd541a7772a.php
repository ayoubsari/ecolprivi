<!DOCTYPE html>
<html>
<head>
  <title>Preinscription</title>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="<?php echo e(asset('assets\img\logoe.ico')); ?>"/>
<link href="https://fonts.googleapis.com/css?family=Dosis|Leckerli+One" rel="stylesheet">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\bootstrap.min.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\font-awesome.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\normalize.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\style.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\animate.css')); ?>">
<link href="https://fonts.googleapis.com/css?family=Dosis|Leckerli+One" rel="stylesheet">
</head>

<body>
<!-- Start navbar -->
<nav class="navbar navbar-default">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
            <span class="navbar-brand" >
    
</span>
      <img  src="<?php echo e(asset('assets\img\logo.png')); ?>" 
      style="width: 100px;height: 65px;    padding-top: 1px;">

    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo e(url('/')); ?>">ACCUEIL</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">CYCLES <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo e(url('/maternelle')); ?>">Maternelle</a></li>
            <li><a href="<?php echo e(url('/primaire')); ?>">Primaire</a></li>
            <li><a href="<?php echo e(url('/college')); ?>">Collége</a></li>
            <li><a href="<?php echo e(url('/lycee')); ?>">Lycée</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">PÔLES D’ ACTIVITES <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo e(url('/pole_art')); ?>">Pôle Artistique</a></li>
            <li><a href="<?php echo e(url('/pole_spo')); ?>">Pôle Sportif</a></li>
            <li><a href="<?php echo e(url('/pole_culture')); ?>">Pôle Culturel</a></li>
            <li><a href="<?php echo e(url('/pole_ecologie')); ?>">Pôle Ecologie</a></li>          
          </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">A PROPROS DE NOUS <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo e(url('/presontation')); ?>">Présentation</a></li>
            <li><a href="<?php echo e(url('/equipe_p')); ?>">Equipe pédagogique</a></li>
            <li><a href="<?php echo e(url('/fond')); ?>">Mot du fondateur</a></li>
          </ul>
        </li>
        <li><a href="<?php echo e(url('/contact')); ?>">CONTACT</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<!-- End navbar -->

<!--Start page Preinscription -->
<div class="cover preinscription">
      <div class="container">
     <h2>Pré-inscription<br>et demande d’information</h2>
     <p class="para_m">Veuillez remplir le formulaire suivant afin de nous permettre d’entrer en contact avec vous.</p>

     <div class="row">
       <div class="col-md-6">
         <form action="<?php echo e(url('preinscription')); ?>"  method="post">
          <?php echo e(csrf_field()); ?>

           <input type="text" name="nom" placeholder="Votre Nom et prénom" class="form-control" data-toggle="prrrr" data-content="Enter le Nom s'il vous plais"  id="user_nom" data-placement="bottom"  >
           <input type="text" name="tel" placeholder="Votre numéro de téléphone" class="form-control" data-toggle="prrr" data-content="Enter le Numéro Télephone"  id="user_tel" data-placement="bottom"  >
           <input type="text" name="email" placeholder="Votre email" class="form-control" 
           data-toggle="em" data-content="Enter le Email s'il vous plais"  id="user_email" data-placement="bottom"  >
           <input type="text" name="nom_enfant" placeholder="Votre Nom et prénom de votre enfant" class="form-control"
           data-toggle="prr" data-content="Enter Nom et prénom de votre enfant"  id="user_enfant" data-placement="bottom"   >
           <textarea placeholder="Votre message" class="form-control" name="message"
           data-toggle="prm" data-content="Enter Le message s'il vous plait"  id="user_message" data-placement="bottom" ></textarea>
           <button type="submit" class="btn btn-primary">envoyer ma demande</button>

         </form><br>
         <center><?php echo $__env->make('part.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>; </center>
       </div>
       <div class="col-md-6" style="">
         <img src="<?php echo e(asset('assets\img\sec7.jpg')); ?>" >
         <p style="height: 102px;background-color: white;color: rgb(0, 167, 217);line-height: 31px;">          
          <i class="fa fa-phone" aria-hidden="true"></i>Télephone :0649264642<br>
          <i class="fa fa-map-marker" aria-hidden="true"></i> Adresse :111 maison municipalite <br>
          <i class="fa fa-envelope" aria-hidden="true"></i> Email: Ayoubsabri56@gmail.com<br>
</p>
         </p>
       </div>
     </div>


      </div>
</div>
<!-- End page Preinscription -->

<!-- Start  Footer -->
<div class="footer">
<div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12">
          <h3>Contact</h3>
          <p>Adresse : Angle Boulevard Tantan et rue Bengeurir G.H.N° 4 Almanar Anfa Casablanca 20160 Maroc</p>
        </div>
        <div class="col-md-4 col-sm-6 col-xs-12">
          <h3>Réseaux sociaux</h3>
                <div class="icon">
                  <a  href="" target="_blank"><i class="fa fa-facebook"></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-twitter "></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-google-plus"></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-linkedin"></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-youtube"></i></a>
                 </div>
        </div>
        <div class="col-md-4 col-sm-6 col-xs col-xs-12">
          <h3>Mots clés</h3>
          <p>Ecole, Architecture d'intérieur, Casablanca, Maroc, Design, Design d'objets, Design Graphique, Digital, Formation accréditée, Enseignement supérieur,</p>
        </div>
      </div>
</div>
</div>
<div class="pied">
  <p class="text-center">Copyrights © Développer By<a style="text-decoration: none;color:black;font-weight: bold;" href="http://www.devosystem.com" target="_blank"> Ayoub Sabri </a><span id="date_m"></span></p></div>
<!-- End  Fotter -->
<!--Start Flesh-->
<span class="flech">
  <i class="fa fa-angle-up" aria-hidden="true"></i>
</span>
<!-- End Flesh -->
<script src="<?php echo e(asset('assets\js\jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets\js\bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets\js\validate_preinscription.js')); ?>"></script>
</body>
</html>
