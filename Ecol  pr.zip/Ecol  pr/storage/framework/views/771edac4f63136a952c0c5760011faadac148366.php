<?php if(session()->has('se')): ?>
 			<div class="alert alert-success">
 			<?php echo e(session()->get('se')); ?>	
 			</div>
<?php endif; ?>