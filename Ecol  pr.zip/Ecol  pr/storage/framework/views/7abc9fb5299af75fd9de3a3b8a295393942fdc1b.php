<?php if(session()->has('se')): ?>
 			<div class="alert alert-info" role="alert">
 			<?php echo e(session()->get('se')); ?>	
 			</div>
 		
<?php endif; ?>