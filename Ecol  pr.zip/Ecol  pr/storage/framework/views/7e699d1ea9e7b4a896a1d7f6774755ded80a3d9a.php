<?php $__env->startSection('titre'); ?>
Acutalite
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Start Des Formations-->
<div class="formation">
  <div class="container">
            <div class="box_formation">
              <h3>Accréditation d'une nouvelle Ecole professionnelle</h3>
              <div class="date_p">
                Posté par: 2017-01-02 
              </div>
              <div class="row">

                <div class="col-md-3">
                  <img src="../img/im/for1.jpg" style=" width: 100%;
            height: 128px;" >
                </div>
                <div class="col-md-6">
                  <p>Dans les entreprises, l'application des outils informatiques, d'aide au pilotage et à la décision, des technologies de «datawarehouse» a accru la possibilité de développer des systèmes d’information organisant les données de façon facilement accessible et appropriée à la prise de décisions et les représentant de manière intelligente. Ce qui a pour effet de faciliter le management de la performance de l’entrepris (...) </p>
                  <a href="<?php echo e(url('detail')); ?>" class="btn btn-primary" >Voir plus...<i class="fa fa-chevron-circle-right"></i></a>
                </div>
              </div>
            </div>
              <div class="box_formation">
              <h3>Cérémonie de remise des Diplômes de l'année 2014-2015</h3>
               <div class="date_p">
                Posté par: 2016-05-02 
              </div>
              <div class="row">

                <div class="col-md-3">
                  <img src="../img/im/for2.jpg" style=" width: 100%;
            height: 128px;" >
                </div>
                <div class="col-md-6">
                  <p>Dans les entreprises, l'application des outils informatiques, d'aide au pilotage et à la décision, des technologies de «datawarehouse» a accru la possibilité de développer des systèmes d’information organisant les données de façon facilement accessible et appropriée à la prise de décisions et les représentant de manière intelligente. Ce qui a pour effet de faciliter le management de la performance de l’entrepris (...) </p>
                  <a href="" class="btn btn-primary" >Voir plus...<i class="fa fa-chevron-circle-right"></i></a>
                </div>
              </div>
            </div>
            <div class="box_formation">
              <h3>Accréditation d'une nouvelle Ecole professionnelle</h3>
              <div class="date_p">
                Posté par: 2017-01-02 
              </div>
              <div class="row">

                <div class="col-md-3">
                  <img src="../img/im/for1.jpg" style=" width: 100%;
            height: 128px;" >
                </div>
                <div class="col-md-6">
                  <p>Dans les entreprises, l'application des outils informatiques, d'aide au pilotage et à la décision, des technologies de «datawarehouse» a accru la possibilité de développer des systèmes d’information organisant les données de façon facilement accessible et appropriée à la prise de décisions et les représentant de manière intelligente. Ce qui a pour effet de faciliter le management de la performance de l’entrepris (...) </p>
                  <a href="" class="btn btn-primary" >Voir plus...<i class="fa fa-chevron-circle-right"></i></a>
                </div>
              </div>
            </div>
  </div>
</div>
<!-- End Des Formations-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>