<?php $__env->startSection('content_admin'); ?>

   <div class="content well">
              <h2>Gestion des Sliders</h2>
            </div>
            <?php echo $__env->make('part.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="content_detail">
               <button type="button" class="btn btn-primary bs" data-toggle="modal" data-target="#myModal" style="font-weight: bold"><i class="fa fa-plus" aria-hidden="true"></i> Ajouter Slider</button>

<div class="span7">   
<div class="widget stacked widget-table action-table">
            
        <div class="widget-header"><i class="fa fa-list" style="margin-left: 5px;font-size: 21px;"></i>
          <h3></h3>
        </div> <!-- /widget-header -->
        
        <div class="widget-content">
          
          <table class="table table-striped table-bordered">
            <thead>
              <tr>
                <th>Images</th>
                <th>titre </th>
                <th>Contenu</th>
                <th>date</th>
                <th class="td-actions">
                  Operation
                </th>
              </tr>
            </thead>
            <tbody>

            <!-- Start actualite -->
      <?php $__currentLoopData = $slider_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td style="width: 417px"> <img src="<?php echo e(asset('storage/'.$value->image)); ?>" alt="..." style="width: 100%;height: 169px;"></td>
          <td><?php echo e($value->titre_slider); ?></td>
          <td style="text-align: justify;"><?php echo e($value->contenu); ?></td>
          <td><?php echo e($value->created_at); ?></td>
          <td>

            <form   action="<?php echo e(url('admin/slider/'.$value->id)); ?>"  method="post">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>

             <a href="<?php echo e(url('admin/slider/'.$value->id.'/edit')); ?>" class="btn btn-small btn btn-primary"><i class="fa fa-refresh"></i> Modifier</a>

              <button type="submit" class="btn btn-small btn-danger"><i class="fa fa-trash-o"></i> Supprimer</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End actualite -->
              </tbody>
            </table>
          
        </div> <!-- /widget-content -->
      
      </div> <!-- /widget -->

            </div>
            <center><?php echo e($slider_list->links()); ?></center>
            </div>

<!-- Start Model Ajouter-->
<!-- Trigger the modal with a button -->

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Ajouter nouvelle Actualite</h4>
        </div>
        <div class="modal-body">
          <form style="margin:0px 5px;" action="<?php echo e(url('/admin/slider/store')); ?> " method="post" enctype="multipart/form-data">

       <?php echo e(csrf_field()); ?>

     <!--Start titre -->
     
  <div class="form-group">
  <input type="text" name="titre_slider" placeholder="Titre Slider" class="form-control">



  </div>
     <!--End titre -->
     <!--Start Objet -->
  <div class="form-group">
  <textarea name="contenu_slider" placeholder="contenu" class="form-control" style="height: 100px;"></textarea>
  </div>
     <!--End  Objet -->
    <div class="form-group">
        <label for="">Image</label>
        <input type="file" class="form-control" name="ph">
    </div>
  <input type="submit" name="insert" value="Enregistrer" class="btn btn-primary">
</form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

<!-- End  Model Ajouter-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>