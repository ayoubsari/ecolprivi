<!--  Start de Title  -->
<?php $__env->startSection('titre'); ?>
Contact
<?php $__env->stopSection(); ?>
<!--  End de Title  -->
<?php $__env->startSection('content'); ?>
<!-- Start Contact  -->
<div class="contact">
  <div class="container">
  <h2 class="text-center">CONTACT</h2>
    <div class="row">

      <div class="col-md-6">
    <h3>Contact Information</h3> 
    <div class="adress_c"> 
    <p><i class="fa fa-map-marker" aria-hidden="true"></i>
392, Rue Mustapha El Mâani, Casablanca</p>  
    <p><i class="fa fa-phone" aria-hidden="true"></i>
(+212)(0) 5 22 49 00 08</p>  
</div>
    <!-- Start form contact -->
<div class="conetnu1">
<ul class="list-unstyled">
  <li class="style_css" data-class="one"><i class="fa fa-envelope" aria-hidden="true"></i></li>
  <li data-class="two"><i class="fa fa-map-marker" aria-hidden="true"></i> </li>
  <li data-class="three"><i class="fa fa-phone"" aria-hidden="true"></i></li>
</ul>
<div  class="clear"> </div>
<div class="tabs_content">
<div class="one">
  <form>

    <input type="text" name="" placeholder="Votre nom" class="form-control">
    <input type="email" name="" placeholder="Votre email" class="form-control">

    <textarea class="form-control" placeholder="Message" height="150">
      
    </textarea>
    <button class="btn btn-primary">Envoyer</button>
  </form>
</div>

<div class="two ">
  <h3>Adresse</h3>
<p><i class="fa fa-map-marker" aria-hidden="true"></i>
392, Rue Mustapha El Mâani, Casablanca</p>  
<p><i class="fa fa-map-marker" aria-hidden="true"></i>
34, Av. Omar Ibn Khattab Agdal, Rabat</p>  


</div>


<div class="three ">
<h3>Telephone</h3>
<p><i class="fa fa-phone" aria-hidden="true"></i>
(+212)(0) 5 22 49 00 08</p>  
<p><i class="fa fa-phone" aria-hidden="true"></i>
(+212)(0) 6 22 49 00 08</p>  
<p><i class="fa fa-whatsapp" aria-hidden="true"></i> (+212)(0) 6 49 26 46 42</p>
</div>
</div>
</div>
    <!--End form contact -->

      </div>
      <div class="col-md-6">
    <h3>Trouvez Nous On Map</h3> 
    <div id="googleMap" style="height:401px;width: 100%">
      
    </div>       
      </div>
    </div>
  </div>
</div>

<!-- End Contact -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>