<?php $__env->startSection('content_admin'); ?>
            <div class="content well">
              <h2>Modifier des Sliders</h2>
            </div>


<form style="margin:0px 5px;" action="<?php echo e(url('admin/slider/'.$slider->id)); ?> " method="post" enctype="multipart/form-data">
<input type="hidden" name="_method" value="PUT">
<?php echo e(csrf_field()); ?>

<!--Start titre -->

	<div class="form-group">
	<input type="text" name="titre_slider" placeholder="Titre Slider" value="<?php echo e($slider->titre_slider); ?>" class="form-control">
	</div>
<!--End titre -->
<!--Start Objet -->
	<div class="form-group">
	<textarea name="contenu_slider" placeholder="contenu" class="form-control" style="height: 100px;"><?php echo e($slider->contenu); ?></textarea>
	</div>
<!--End  Objet -->
<!-- Start Image -->
	<div class="form-group">
	<label for="">Image</label>
	<input type="file" class="form-control" name="ph">
	</div>
<!--End Image -->
<input type="submit" name="insert" value="Enregistrer" class="btn btn-primary">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>