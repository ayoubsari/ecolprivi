<?php $__env->startSection('titre'); ?>
Bievenu site
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!--Start Slider  bar-->
<!--Start Slider 1 -->
<div class="section">
  
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="<?php echo e(asset('assets\img\IDME11.jpg')); ?>" alt="...">
      <div class="carousel-caption">
        ...
      </div>
    </div>
    <div class="item">
      <img src="<?php echo e(asset('assets\img\ensas-pano1.jpg')); ?>" alt="...">
      <div class="carousel-caption">
        ...
      </div>
    </div>
    <div class="item">
      <img src="<?php echo e(asset('assets\img\ceremonie1.jpg')); ?>"  alt="...">
      <div class="carousel-caption">
        ...
      </div>
    </div>
   
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


</div>
<!-- End slider 1 -->

<!--End   Slidar bar-->
<!--start Actialite  -->
<div class="acti">
  <div class="container">

      <h2 class="text-center">NOS ACTUALITÉS</h2>
    <div class="row">
            <div class="col-md-4">

              <div class="box">
                <img src="<?php echo e(asset('assets\img\im\box1.jpg')); ?>">
                <p class="date">Posté par: 2017-01-02</p>
                <p class="detail">SUP’TECHNOLOGY aborde l’enseignement par une approche moderne et évolutive. L’innovation et la R&D sont au centre des préoccupations d’une équipe pédagogique alerte et à l’affût... </p>
                <a href="<?php echo e(url('detail')); ?>" class="btn btn-primary s">Voir plus...<i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
</a>
              </div>
             
            </div>
            <div class="col-md-4">
              <div class="box">
                <img   src="<?php echo e(asset('assets\img\im\box2.png')); ?>" >
                <p class="date">Posté par: 2017-01-02</p>
                <p class="detail">SUP’TECHNOLOGY aborde l’enseignement par une approche moderne et évolutive. L’innovation et la R&D sont au centre des préoccupations d’une équipe pédagogique alerte et à l’affût...  </p>
                <a href="" class="btn btn-primary s">Voir plus...<i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
</a>
              </div>
            </div>
            <div class="col-md-4">
              <div class="box">
                <img src="<?php echo e(asset('assets\img\im\box3.png')); ?>">
                <p class="date">Posté par: 2017-01-02</p>
                <p class="detail">SUP’TECHNOLOGY aborde l’enseignement par une approche moderne et évolutive. L’innovation et la R&D sont au centre des préoccupations d’une équipe pédagogique alerte et à l’affût...</p>
                <a href="" class="btn btn-primary s">Voir plus...<i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
</a>
              </div>
            </div>
    </div>
  </div>

</div>
<!-- End  Actialite  -->
<!-- Start awsome  -->
<div class="awsom">
  <div class="container">
    <div class="row text-center">
            <div class="col-md-3 ">

              <i class="fa fa-lightbulb-o"></i>
              <p>MANIEL ET INFORMATIQUE</p>
            </div>
            <div class="col-md-3">
              <i class="fa fa-keyboard-o"></i>
              <p>MANIEL ET INFORMATIQUE</p>
            </div>
            <div class="col-md-3">
              <i class="fa fa-calendar-o"></i>
              <p>MANIEL ET INFORMATIQUE</p>
            </div>
            <div class="col-md-3">
              <i class="fa fa-desktop"></i>
              <p>MANIEL ET INFORMATIQUE</p>
            </div>
    </div>
  </div>
</div>
<!--  End awsome -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>