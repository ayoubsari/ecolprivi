<?php $__env->startSection('content_admin'); ?>
            <div class="content well">
              <h2>Gestion des Actualites</h2>
            </div>
            <?php echo $__env->make('part.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="content_detail">
            <a href="<?php echo e(url('/admin/ajouter_art')); ?>"  class="btn btn-primary bs">Ajouter nouvelle <br>Actualite</a>

<div class="span7">   
<div class="widget stacked widget-table action-table">
            
        <div class="widget-header"><i class="fa fa-list" style="margin-left: 5px;font-size: 21px;"></i>
          <h3></h3>
        </div> <!-- /widget-header -->
        
        <div class="widget-content">
          
          <table class="table table-striped table-bordered">
            <thead>
              <tr>
                <th>Titre</th>
                <th>Images</th>
                <th>Objet</th>
                <th>date </th>
                <th class="td-actions">
                  Operation
                </th>
              </tr>
            </thead>
            <tbody>

            <!-- Start actualite -->
      <?php $__currentLoopData = $act_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><p><?php echo e($value->titre); ?></p></td>
          <td> <img src="<?php echo e(asset('storage/'.$value->image)); ?>" alt="..." height="100"></td>

          <td><p><?php echo e($value->objet); ?></p></td>
          <td><?php echo e($value->created_at); ?></td>
          <td>

            <form   action="<?php echo e(url('admin/'.$value->id)); ?>"  method="post">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>

             <a href="<?php echo e(url('admin/'.$value->id.'/edit')); ?>" class="btn btn-small btn btn-primary"><i class="fa fa-refresh"></i> Modifier</a>

              <button type="submit" class="btn btn-small btn-danger"><i class="fa fa-trash-o"></i> Supprimer</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End actualite -->
  

              </tbody>
            </table>
          
        </div> <!-- /widget-content -->
      
      </div> <!-- /widget -->
            </div>
            </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>