<!-- Start title -->
<?php $__env->startSection('titre'); ?>
detail
<?php $__env->stopSection(); ?>
<!-- End Title  -->
<?php $__env->startSection('content'); ?>
<div class="detail">
	<div class="container">
		<div class="row">
					<div class="col-md-8">
					<h3>Accréditation d'une nouvelle Ecole professionnelle</h3>
					<div class="date_p">
					Posté par: 2017-01-02 
					</div>
					<a  href="">
					<img src="<?php echo e(asset('assets\img\im\for1.jpg')); ?>">
					</a>
					<p>
						Dans les entreprises, l'application des outils informatiques, d'aide au pilotage et à la décision, des technologies de «datawarehouse» a accru la possibilité de développer des systèmes d’information organisant les données de façon facilement accessible et appropriée à la prise de décisions et les représentant de manière intelligente. Ce qui a pour effet de faciliter le management de la performance de l’entreprise.
					</p>
					<p>
					La place centrale qu'occupe l'information dans le processus de décision n'est plus à démontrer. Parallèlement à l’évolution des outils informatiques d’aide à la décision, les tentatives de rénovation du contrôle de gestion, se sont succédées et ont fait pris conscience de la nécessité de dépasser la vision seulement financière de l'entreprise pour prendre en compte le caractère multidimensionnel de celle-ci. Dans le même temps, on ne se contente plus de mesurer la performance ; on cherche à agir sur ses déterminants et à appréhender la relation de causalité pouvant exister entre chaque action et sa conséquence sur l’objectif stratégique.
					</p>
					<p>
						Dans cette vision, la licence professionnelle d'Université Informatique Décisionnelle et Management des Entreprises répond à l'intérêt croissant des entreprises pour le management, qui rencontre aujourd'hui l'opportunité technologique afin mettre en place une architecture informatique, communément appelée «informatique décisionnelle», appuyée en règle générale sur un entrepôt (et/ou des magasins) de données.
					</p>
					<a href="<?php echo e(url('actualite')); ?>" class="btn btn-primary">Retour</a>
					</div>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<!-- Start Details -->


<!-- End Detials -->
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>