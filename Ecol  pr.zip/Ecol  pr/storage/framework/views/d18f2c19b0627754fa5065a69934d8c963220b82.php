<!DOCTYPE html>
<head>
<meta charset="utf-8">
<link rel="shortcut icon" href="<?php echo e(asset('assets\img\ensa.ico')); ?>"/>
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\bootstrap.min.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\style1.css')); ?>">
<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>
    <div class="brand">
      <ul class="nav_bar pull-right">
       <li>Bienvenu , Administrateur</li>
        <li><a href=""><i class="fa fa-sign-out fa-fw"></i>Deconnecte</a></li>
      </ul>
    </div>
    <div class="contenu">
    <div class="row">
        <div class="col-md-3">

            <ul class="nav nav-pills nav-stacked">
                 <div class="logo"><img src="<?php echo e(asset('assets\img\logo1.png')); ?>"></div>
                <li class="active"><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-home fa-fw"></i>Tableau de bord</a></li>
                <li><a href="<?php echo e(url('admin/actualite')); ?>"><i class="fa fa-list-alt fa-fw"></i>Gestion de Actualite</a></li>
                <li><a href="<?php echo e(url('admin/galarie')); ?>"><i class="fa fa-file-o fa-fw"></i>Gestion de Galery</a></li>
                <li><a href=""><i class="fa fa-bar-chart-o fa-fw"></i>Gestion de Detaile</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-table fa-fw"></i>Table</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-tasks fa-fw"></i>Forms</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-calendar fa-fw"></i>Calender</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-book fa-fw"></i>Library</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-pencil fa-fw"></i>Applications</a></li>
                <li><a href="http://www.jquery2dotnet.com"><i class="fa fa-cogs fa-fw"></i>Settings</a></li>
            </ul>
        </div>
        <div class="col-md-9 ">


            <!-- Start Content page admin-->
         <?php echo $__env->yieldContent('content_admin'); ?>
            <!-- End Content page admin -->

        </div>
    </div>
    </div>


</body>
</html>