<?php $__env->startSection('content_adminn'); ?>
            <div class="content well">
              <h2>Modifier  des Primary</h2>
            </div>


<form style="margin:0px 5px;" action="<?php echo e(url('admin/galarie_p/'.$gal->id)); ?> " method="post" enctype="multipart/form-data">
<input type="hidden" name="_method" value="PUT">
			 <?php echo e(csrf_field()); ?>


    <div class="form-group">
				<label for="">Image</label>
				<input type="file" class="form-control" name="ph_primary">
				</div>
    <button type="submit" class="btn btn-primary">
        <i class="fa fa-refresh"></i> Modifier
    </button>
	
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar_adminn', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>