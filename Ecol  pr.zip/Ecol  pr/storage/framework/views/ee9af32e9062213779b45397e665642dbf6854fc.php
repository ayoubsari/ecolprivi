<!DOCTYPE html>
<html>
<head>

	<title><?php echo $__env->yieldContent('titre'); ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="<?php echo e(asset('assets\img\ensa.ico')); ?>"/>
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\bootstrap.min.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\font-awesome.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\normalize.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\style.css')); ?>">
<link rel="stylesheet"  href="<?php echo e(asset('assets\style\animate.css')); ?>">
</head>
<style type="text/css">

</style>
<body>
<!--Start body-->
<div class="top_header">
  <div class="container">
    <div class="col-md-5 pull-left">
      <p>Ecole privi maroc, Ecol informatique Safi</p>
    </div>
    <div class="col-md-4 ">
      <div class="contact_top pull-right">
      <i class="fa fa-phone" aria-hidden="true"></i>&nbsp
      <span>tel:&nbsp</span><span class="tel_top">+212.0524.66.91.55 / 0662138933 </span>
      </div>
    </div>
    <div class="col-md-3 ">       
    <ul class="media pull-right list-unstyled">
    <li><a href="" id="f"><i class="fa fa-facebook "></i></a></li>
    <li><a href="facebook.com" target="_blank" id="t"><i class="fa fa-twitter "></i></a></li>
    <li><a href="" id="p"><i class="  fa fa-google-plus"></i></a></li>
    <li><a href="" id="l"><i class="fa fa-linkedin"></i></a></li>   
    <li><a href="" id="w"><i class="fa fa-pinterest "></i></a></li>
    <li><a href="" id="s"><i class="fa fa-stumbleupon"></i></a></li>
  </ul>
    </div>

  </div>

</div>
<!--Start Navigation bar-->
<nav class="navbar navbar-default">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <span class="navbar-brand" >
      <span style="color:red;font-weight: bold;font-size:18px;"></span>
</span>
      <img src="<?php echo e(asset('assets\img\logo.png')); ?>"
      style="width: 100px;height: 65px;    padding-top: 1px;">

    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo e(url('/')); ?>" class="act"><i class="fa fa-home"></i>Accueil</a></li>
        <li><a href="<?php echo e(url('actualite')); ?>"><i class="fa fa-play-circle"></i>Actualités</a></li>
        <li><a href="<?php echo e(url('galarie')); ?>"><i class="fa fa-picture-o"></i>Galarie</a></li>
        <li><a href="<?php echo e(url('derecteur')); ?>""><i class="fa fa-user"></i>Mote Directeur</a></li>
        <li><a href="<?php echo e(url('contact')); ?>"><i class="fa fa-envelope"></i>Contact</a></li>
      </ul>


    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<!--End Navigation bar-->

<!-- Start Content -->
<?php echo $__env->yieldContent('content'); ?>
<!--  End Content  -->

<!-- Start  Footer -->
<div class="footer">
<div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12">
          <h3>Contact</h3>
          <p>Adresse : Angle Boulevard Tantan et rue Bengeurir G.H.N° 4 Almanar Anfa Casablanca 20160 Maroc</p>
        </div>
        <div class="col-md-4 col-sm-6 col-xs-12">
          <h3>Réseaux sociaux</h3>
                <div class="icon">
                  <a  href="" target="_blank"><i class="fa fa-facebook"></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-twitter "></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-google-plus"></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-linkedin"></i></a>
                  <a class="l" href="" target="_blank"><i class="fa fa-youtube"></i></a>
                 </div>
        </div>
        <div class="col-md-4 col-sm-6 col-xs col-xs-12">
          <h3>Mots clés</h3>
          <p>Ecole, Architecture d'intérieur, Casablanca, Maroc, Design, Design d'objets, Design Graphique, Digital, Formation accréditée, Enseignement supérieur,</p>
        </div>
      </div>
</div>
</div>
<div class="pied">
  <p class="text-center">Copyrights © Développer By<a style="text-decoration: none;color:white;font-weight: bold;" href="http://www.devosystem.com" target="_blank"> Devosystem </a>2017</p></div>
<!-- End  Fotter -->
<!--Start Flesh-->
<span class="flech">
  <i class="fa fa-angle-up" aria-hidden="true"></i>
</span>
<!-- End Flesh -->


<script src="<?php echo e(asset('assets\js\jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets\js\gallery.js')); ?>"></script>
<script src="<?php echo e(asset('assets\js\bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets\js\function.js')); ?>"></script>
<!-- <script src="http://maps.googleapis.com/maps/api/js"></script> -->
<!-- <script src="<?php echo e(asset('assets\js\js_map.js')); ?>" ></script> -->
</body>
</html>