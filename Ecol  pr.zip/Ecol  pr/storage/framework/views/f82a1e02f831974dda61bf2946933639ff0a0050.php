<?php $__env->startSection('content_admin'); ?>
            <div class="content well">
              <h2>Gestion des Actualites</h2>
            </div>
            <?php echo $__env->make('part.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="content_detail">

               <button type="button" class="btn btn-primary bs" data-toggle="modal" data-target="#myModal"  style="font-weight: bold;"><i class="fa fa-plus" aria-hidden="true"></i> Ajouter Actualite</button>
            
<div class="span7">   
<div class="widget stacked widget-table action-table">
            
        <div class="widget-header"><i class="fa fa-list" style="margin-left: 5px;font-size: 21px;"></i>
          <h3></h3>
        </div> <!-- /widget-header -->
        
        <div class="widget-content">
          
          <table class="table table-striped table-bordered">
            <thead>
              <tr>
                <th>Titre</th>
                <th>Images</th>
                <th>Objet</th>
                <th>date </th>
                <th class="td-actions">
                  Operation
                </th>
              </tr>
            </thead>
            <tbody>

            <!-- Start actualite -->
      <?php $__currentLoopData = $act_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><p><?php echo e($value->titre); ?></p></td>
          <td> <img src="<?php echo e(asset('storage/'.$value->image)); ?>" alt="..." height="100"></td>

          <td><p><?php echo e(str_limit($value->objet,300)); ?></p></td>
          <td><?php echo e($value->created_at); ?></td>
          <td>

            <form   action="<?php echo e(url('admin/actualite/'.$value->id)); ?>"  method="post">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>

             <a href="<?php echo e(url('admin/actualite/'.$value->id.'/edit')); ?>" class="btn btn-small btn btn-primary"><i class="fa fa-refresh"></i> Modifier</a>

              <button type="submit" class="btn btn-small btn-danger"><i class="fa fa-trash-o"></i> Supprimer</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End actualite -->
  

              </tbody>
            </table>
          <center><?php echo e($act_list->links()); ?></center>
        </div> <!-- /widget-content -->
      
      </div> <!-- /widget -->
            </div>
            </div>




<!-- Start Model Ajouter-->
<!-- Trigger the modal with a button -->

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Ajouter nouvelle Actualite</h4>
        </div>
        <div class="modal-body">
          <form style="margin:0px 5px;" action="<?php echo e(url('/admin/actualite/store')); ?> " method="post" enctype="multipart/form-data">

       <?php echo e(csrf_field()); ?>

     <!--Start titre -->
     
  <div class="form-group <?php if($errors->get('titre')): ?>  has-error  <?php endif; ?>">
  <input type="text" name="titre" placeholder="Titre" class="form-control">

        <?php if($errors->get('titre')): ?>
                    <?php $__currentLoopData = $errors->get('titre'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li><?php echo e($message); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

  </div>
     <!--End titre -->
     <!--Start Objet -->
  <div class="form-group <?php if($errors->get('objet')): ?>  has-error  <?php endif; ?>">
  <textarea name="objet" placeholder="Objet" class="form-control" style="height: 100px;"></textarea>
        <?php if($errors->get('objet')): ?>
                    <?php $__currentLoopData = $errors->get('objet'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li><?php echo e($message); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
  </div>
     <!--End  Objet -->
    <div class="form-group">
        <label for="">Image</label>
        <input type="file" class="form-control" name="ph">
    </div>
  <input type="submit" name="insert" value="Enregistrer" class="btn btn-primary">
</form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

<!-- End  Model Ajouter-->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>